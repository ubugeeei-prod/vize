
import assert from "node:assert/strict";
import { spawnSync } from "node:child_process";
import fs from "node:fs";
import path from "node:path";
import os from "node:os";
import { createHash } from "node:crypto";
import { loadCorpus, wholeJson, sha256 } from "/Users/ubugeeei/Source/github.com/ubugeeei-prod/vize.acceptance-lint-8090-v0443/tests/tooling/lint-default-correctness-reference.mjs";

const root = "/Users/ubugeeei/Source/github.com/ubugeeei-prod/vize.acceptance-lint-8090-v0443";
const out = "/var/folders/8k/gm2q62k57yb9h1kmw2kf2tzm0000gn/T/vize-8090-public-epwnn06w";
const binary = path.join(out, "installed/vize");
const revision = "15e116fa258c7aaba5c6fdd2456442535605abe8";
const overrides = ["NODE_OPTIONS", "VIZE_PREFER_WORKSPACE_BINDING", "NAPI_RS_NATIVE_LIBRARY_PATH", "NAPI_RS_FORCE_WASI", "VIZE_ALLOW_NATIVE_VERSION_MISMATCH", "CORSA_PATH", "CORSA_EXECUTABLE", "TSGO_PATH", "TSGO_EXECUTABLE"];
for (const key of overrides) assert.ok(!process.env[key], "runtime override must be absent: " + key);
const json = (file) => JSON.parse(fs.readFileSync(path.join(out, file), "utf8"));
const release = json("release-metadata.json");
const run = json("release-run.json");
const tag = json("release-tag-object.json");
const ref = json("release-tag-ref.json");
assert.equal(release.tag_name, "v0.443.0");
assert.equal(release.draft, false);
assert.equal(release.prerelease, false);
assert.equal(ref.object.sha, tag.sha);
assert.equal(tag.object.sha, revision);
assert.equal(tag.object.type, "commit");
assert.equal(run.id, 38081199501);
assert.equal(run.head_sha, revision);
assert.equal(run.conclusion, "success");
assert.equal(run.path, ".github/workflows/release.yml");
const asset = release.assets.find((a) => a.name === "vize-aarch64-apple-darwin.tar.gz");
const archive = path.join(out, "distribution", asset.name);
assert.equal("sha256:" + sha256(fs.readFileSync(archive)), asset.digest);
const actualRevision = spawnSync("git", ["rev-parse", "HEAD"], {cwd: root,encoding:"utf8"});
assert.equal(actualRevision.status, 0);
assert.equal(actualRevision.stdout.trim(), revision);
const version = spawnSync(binary, ["--version"], {encoding: "utf8"});
assert.equal(version.status, 0);
assert.equal(version.stderr, "");
assert.match(version.stdout, /vize 0\.443\.0/);
const binarySha = sha256(fs.readFileSync(binary));
const evidence = {
  schema: "vize.public-installed-lint-defaults",
  version: 1,
  startedAt: new Date().toISOString(),
  authority: {
    tag: release.tag_name, revision, releaseRun: run.id,
    releaseRunUrl: run.html_url, releaseUrl: release.html_url,
    platform: "aarch64-apple-darwin",
    archive: { path: archive, sha256: asset.digest, url: asset.browser_download_url },
    binary: { path: binary, sha256: binarySha, version: version.stdout },
    runtimeOverrides: Object.fromEntries(overrides.map((k)=>[k,process.env[k] || ""])),
  },
  sourceAuthorities: [],
  runs: [],
};
const artifact = path.join(out, "installed-cli-defaults.json");
const persist = () => fs.writeFileSync(artifact, JSON.stringify(evidence,null,2)+"\n");
const files = [
 "tests/_fixtures/lint-default-correctness/cases.json",
 "tests/_fixtures/lint-default-migrations/cases.json",
 "tests/_fixtures/n8n-cli-adoption.json",
 "tests/tooling/lint-default-correctness-cli.test.mjs",
 "tests/tooling/lint-default-correctness-reference.mjs",
 "tests/tooling/lint-default-migrations-cli.test.mjs",
 "crates/vize_patina/src/preset.rs", "crates/vize_patina/src/rule/happy_path.rs",
 "crates/vize_patina/src/linter/compatibility.rs", "crates/vize_patina/src/linter/engine/rule_sets.rs",
];
for (const file of files) evidence.sourceAuthorities.push({file,sha256:sha256(fs.readFileSync(path.join(root,file)))});
persist();
const first = loadCorpus(root);
const second = JSON.parse(fs.readFileSync(path.join(root, "tests/_fixtures/lint-default-migrations/cases.json"),"utf8"));
const projection = JSON.parse(fs.readFileSync(path.join(root,"tests/_fixtures/n8n-cli-adoption.json"),"utf8"));
assert.equal(second.schema,"vize.lint.default-migrations");
assert.equal(second.cases.length,12);
assert.equal(Object.keys(projection.linter.rules).length,51);
evidence.corpora = {first,second,projection};
persist();
const scenarios = first.cases.filter((e)=>e.kind === "vue").flatMap((entry)=>[
 {entry,preset:null,config:null,findings:entry.diagnostics,slice:"first"},
 {entry,preset:"recommended",config:null,findings:entry.diagnostics,slice:"first"},
 {entry,preset:"ecosystem",config:null,findings:entry.diagnostics,slice:"first"},
 {entry,preset:"incremental",config:null,findings:[],slice:"first"},
]);
for (const entry of first.cases.slice(0,6)) {
 scenarios.push({entry,preset:null,findings:entry.baselineDiagnostics,slice:"first",config:JSON.stringify({linter:{rules:Object.fromEntries(first.promotedRules.map((n)=>[n,"off"]))}})+"\n"});
}
for (const version of first.configuredVueVersions) {
 for (const entry of first.cases.slice(0,6)) scenarios.push({entry,preset:null,slice:"first",config:JSON.stringify({vue:{version}})+"\n",findings:version==="3"?entry.diagnostics:entry.baselineDiagnostics});
}
assert.equal(scenarios.length,80);
for (const entry of second.cases) {
 scenarios.push(...[
  ...[null,"recommended","essential","ecosystem","opinionated","nuxt"].map((preset)=>({entry,preset,config:null,findings:preset==="essential"?entry.essentialDiagnostics:entry.diagnostics,slice:"second"})),
  {entry,preset:"incremental",config:null,findings:[],slice:"second"},
  {entry,preset:null,slice:"second",findings:entry.baselineDiagnostics,config:JSON.stringify({linter:{rules:Object.fromEntries(second.promotedRules.map((n)=>[n,"off"]))}})+"\n"},
  ...second.configuredVueVersions.map((version)=>({entry,preset:null,slice:"second",config:JSON.stringify({vue:{version}})+"\n",findings:version==="3"?entry.diagnostics:entry.baselineDiagnostics})),
  {entry,preset:null,slice:"second",config:JSON.stringify({linter:projection.linter})+"\n",findings:entry.essentialDiagnostics},
 ]);
}
assert.equal(scenarios.length,224);
const directory = fs.mkdtempSync(path.join(os.tmpdir(),"vize-installed-lint-controls-"));
try {
 for (const {entry,preset,config,findings,slice} of scenarios) {
  const fixture = path.join(root,"tests/_fixtures",slice==="first"?"lint-default-correctness":"lint-default-migrations",entry.filename+".fixture");
  assert.equal(fs.readFileSync(fixture,"utf8"),entry.source);
  fs.writeFileSync(path.join(directory,entry.filename),entry.source);
  if(config) fs.writeFileSync(path.join(directory,"vize.config.json"),config);
  const argv=["lint",...(config?["-c","vize.config.json"]:["--no-config"]),...(preset?["--preset",preset]:[]),"--format","json","--locale","en","--help-level","none",entry.filename];
  const observed = spawnSync(binary,argv,{cwd:directory,env:process.env,encoding:"utf8",timeout:60000,maxBuffer:4*1024*1024});
  const record = {slice,id:entry.id,argv,config,status:observed.status,signal:observed.signal,error:observed.error?{name:observed.error.name,message:observed.error.message}:null,stdout:observed.stdout??"",stderr:observed.stderr??"",expected:wholeJson(entry,findings),expectedStatus:findings.some((f)=>f.severity==="error")?1:0};
  evidence.runs.push(record);persist();
  const bytes=fs.readFileSync(path.join(directory,entry.filename));
  record.input={text:bytes.toString("utf8"),bytes:bytes.length,sha256:sha256(bytes)};persist();
  assert.equal(record.error,null);assert.equal(record.signal,null);assert.equal(record.status,record.expectedStatus);assert.equal(record.stderr,"");assert.equal(record.input.text,entry.source);
  record.actual=JSON.parse(record.stdout);persist();
  assert.deepEqual(record.actual,record.expected, slice+" / "+entry.id+" / "+preset);
  if(config) {assert.equal(fs.readFileSync(path.join(directory,"vize.config.json"),"utf8"),config);fs.unlinkSync(path.join(directory,"vize.config.json"));}
  fs.unlinkSync(path.join(directory,entry.filename));
 }
 assert.equal(sha256(fs.readFileSync(binary)),binarySha);
 evidence.completedAt=new Date().toISOString();evidence.status="passed-224-complete-observations";persist();
 console.log(JSON.stringify({status:evidence.status,runs:evidence.runs.length,artifact,binarySha,revision}));
} catch (error) {
 evidence.failure={name:error.name,message:error.message};persist();throw error;
} finally {
 persist();fs.rmSync(directory,{recursive:true,force:true});
}

