<script setup lang="ts">
defineEmits<{
  click: [];
  change: [value: number];
}>();
</script>

<template>
  <button type="button" @click="$emit('clik')">a</button>
  <button type="button" @click="$emit('change', 'x')">b</button>
</template>
