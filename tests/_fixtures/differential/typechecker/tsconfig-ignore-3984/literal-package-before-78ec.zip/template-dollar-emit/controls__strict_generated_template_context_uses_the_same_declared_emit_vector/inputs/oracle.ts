import { defineEmits, defineModel } from 'vue';
const emit = defineEmits<{ click: []; change: [value: number] }>();
emit('clik');
emit('change', 'x');
