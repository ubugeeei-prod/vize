import { defineEmits, defineModel } from 'vue';
function setup<T extends number>(value: T) { const emit = defineEmits<{ change: [value: T] }>(); emit('change', value); }

