<script setup lang="ts" generic="T extends number">
defineProps<{ value: T }>();
defineEmits<{ change: [value: T] }>();
</script>
<template>
  <button @click="$emit('change', value)">ok</button>
</template>
