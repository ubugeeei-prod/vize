<script setup lang="ts">
function defineEmits<T>() { return (value: T) => value; }
const ordinary = defineEmits<number>();
ordinary(1);
</script>
<template>
  <button @click="$emit('anything', 'x')">ok</button>
</template>
