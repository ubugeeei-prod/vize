import { defineEmits, defineModel } from 'vue';
type Events = { (event: 'change', value: number): void }; const emit = defineEmits<Events>();
emit('change', 1);
