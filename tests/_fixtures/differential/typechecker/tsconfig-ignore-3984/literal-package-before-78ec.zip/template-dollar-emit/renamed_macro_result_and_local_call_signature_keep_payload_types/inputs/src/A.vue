<script setup lang="ts">
type Events = { (event: 'change', value: number): void };
const dispatch = defineEmits<Events>();
</script>
<template>
  <button @click="$emit('change', 1); dispatch('change', 2)">ok</button>
</template>
