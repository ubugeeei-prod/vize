import { defineEmits, defineModel } from 'vue';
const model = defineModel<string>(); const emit = defineEmits<{ change: [value: number]; 'update:modelValue': [value: typeof model.value] }>();
emit('update:modelValue', 'x');
emit('update:modelValue', undefined);
emit('update:modelValue', 1);
