<script setup lang="ts">
defineEmits<{ change: [value: number] }>();
defineModel<string>();
</script>
<template>
  <button @click="$emit('update:modelValue', 'x'); $emit('update:modelValue', undefined); $emit('change', 1)">ok</button>
  <button @click="$emit('update:modelValue', 1)">bad</button>
</template>
