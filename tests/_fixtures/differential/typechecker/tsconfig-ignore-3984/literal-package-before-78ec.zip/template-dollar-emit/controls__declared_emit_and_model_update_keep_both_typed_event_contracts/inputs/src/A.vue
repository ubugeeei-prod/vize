<script setup lang="ts">
defineEmits<{ change: [value: number] }>();
defineModel<string>({ required: true });
</script>
<template>
  <button @click="$emit('update:modelValue', 'x'); $emit('change', 1)">ok</button>
  <button @click="$emit('update:modelValue', 1)">bad</button>
</template>
