import { defineEmits, defineModel } from 'vue';
const model = defineModel<string>({ required: true }); const emit = defineEmits<{ change: [value: number]; 'update:modelValue': [value: typeof model.value] }>();
emit('update:modelValue', 'x');
emit('update:modelValue', 1);
