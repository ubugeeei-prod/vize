import { defineEmits, defineModel } from 'vue';
const emit = defineEmits<{ click: []; change: [value: number] }>();
emit('click');
emit('change', 1);
