<script setup lang="ts">
defineEmits<{
  click: [];
  change: [value: number];
}>();
</script>

<template>
  <button type="button" @click="$emit('click')">a</button>
  <button type="button" @click="$emit('change', 1)">b</button>
</template>
