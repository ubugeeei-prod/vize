import { defineEmits, defineModel } from 'vue';
const emit: import('vue').ComponentPublicInstance['$emit'] = () => {};
emit('anything', 'x');
