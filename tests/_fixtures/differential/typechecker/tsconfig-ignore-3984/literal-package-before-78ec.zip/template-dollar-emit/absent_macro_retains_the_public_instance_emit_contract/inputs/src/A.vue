<template>
  <button @click="$emit('anything', 'x')">ok</button>
</template>
