<script setup lang="ts">
defineEmits(['click', 'change']);
</script>
<template>
  <button @click="$emit('change', 'x')">ok</button>
  <button @click="$emit('clik')">bad</button>
</template>
