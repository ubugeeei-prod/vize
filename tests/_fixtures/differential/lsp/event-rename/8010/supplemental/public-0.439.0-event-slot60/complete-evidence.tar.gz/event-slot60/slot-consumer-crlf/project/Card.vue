<script setup lang="ts">
defineSlots<{
  heading(props: { title: string }): unknown;
}>();
</script>

<template>
  <section>
    <slot name="heading" title="Hello" />
  </section>
</template>
