<script setup lang="ts">
const emit = defineEmits<{
  update: [value: boolean];
}>();
const change = true;

function flip() {
  emit("update", change);
}
</script>

<template>
  <button @click="flip">toggle</button>
</template>
