<script setup lang="ts">
const emit = defineEmits<{ (event: "nextEvent", id: string): void }>();
function fire() {
  emit("nextEvent", "item");
}
function unrelated(emit: (name: string, id: string) => void) {
  emit("saveItem", "shadow");
}
void unrelated;
</script>

<template><button @click="fire">save</button></template>
