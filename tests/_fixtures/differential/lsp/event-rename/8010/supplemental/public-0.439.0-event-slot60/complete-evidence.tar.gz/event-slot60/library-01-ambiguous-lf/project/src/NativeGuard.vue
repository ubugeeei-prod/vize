<script setup lang="ts">
const nativeGuard: number = 'wrong';
</script>
<template>{{ nativeGuard }}</template>
