<script setup lang="ts">
let emit = defineEmits<{
  change: [value: boolean];
}>();

function flip() {
  emit("change", true);
}
</script>

<template>
  <button @click="flip">toggle</button>
</template>
