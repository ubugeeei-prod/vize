<script setup lang="ts">
const payload = { title: "Hello" };
const header = "local header";
defineSlots<{
  "heading": (props: { title: typeof payload.title }) => unknown;
  header(props: { title: string }): unknown;
}>();
</script>

<template>
  <section>
    <slot name="heading" title="Hello" />
    <slot name="header" title="Hello" />
    <p>{{ header }}</p>
  </section>
</template>
