<script setup lang="ts">
defineEmits<{ saveItem: [id: string] }>();
</script>

<template><span>unrelated</span></template>
