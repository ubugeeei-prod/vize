import assert from 'node:assert/strict';
import fs from 'node:fs';import path from 'node:path';
import {LspSession} from './session.ts';
import {profiles,preparePrefixWorkspace,prefixParams,nativeCaptures,sha256,inputHashes} from "/Users/ubugeeei/Source/github.com/ubugeeei-prod/vize.fix-lsp-type-query-warm-state-10622/tests/tooling/support/tag-prefix-classification-10622.ts";
const folder=fs.realpathSync(process.cwd()),provider=JSON.parse(fs.readFileSync('provider.json'));const rows=[];
for(const profile of profiles){
 const output=path.join(folder,'profiles',profile.name),capture=path.join(output,'native');fs.mkdirSync(capture,{recursive:true});process.env.VIZE_COMPONENT_TYPE_CAPTURE=capture;
 const {workspace,source,uri}=preparePrefixWorkspace(profile,provider.dependencies.runtime.path,provider.dependencies.vue.path,output);
 const session=new LspSession({repoRoot:provider.driver.sourceRoot,binary:provider.provider.wrapper.path});const packets=[];session.responseObservers.push(p=>packets.push(p));
 const result={profile:profile.name,sourceSha256:sha256(source),rows:[]};
 try{await session.initialize(workspace,{editor:true,lint:false,typecheck:true,ecosystem:false});session.notify('textDocument/didOpen',{textDocument:{uri,languageId:'vue',version:1,text:source}});await session.waitForNotification('textDocument/publishDiagnostics',p=>p.uri===uri&&p.version===1,45000);
 for(const q of profile.queries){const previous=new Set(nativeCaptures(capture).map(v=>v.file));const params=prefixParams(source,uri,q);let id;const response=await session.request('textDocument/completion',params,60000,rpcId=>{id=rpcId;return []});const packet=packets.find(p=>p.id===id);assert.deepEqual(packet,{jsonrpc:'2.0',id,result:response});const captures=nativeCaptures(capture).filter(v=>!previous.has(v.file));const requests=captures.flatMap(v=>v.records.filter(r=>r.stage==='request').map(r=>r.value));
 result.rows.push({name:q.name,position:params.position,packet,nativeRequests:requests.map(r=>({positions:r.positions,sourceSha256:sha256(r.source),vueModulePosition:r.vueModulePosition})),captureFiles:captures.map(v=>({file:v.file,sha256:v.sha256}))});fs.writeFileSync(path.join(output,'observations.json'),JSON.stringify(result,null,2)+'\n');console.log(profile.name,q.name,'items',Array.isArray(response)?response.length:JSON.stringify(response),'native',requests.map(r=>r.positions.length));}
 }finally{await session.shutdown();await session.waitForClosed();fs.writeFileSync(path.join(output,'stderr.log'),session.stderrText);}
 rows.push(result);fs.writeFileSync('observations.json',JSON.stringify({authority:'published-npm-consumer',releaseVersion:'0.567.0',providerReceiptSha256:sha256(fs.readFileSync('provider.json')),inputHashes,profiles:rows},null,2)+'\n');
}
