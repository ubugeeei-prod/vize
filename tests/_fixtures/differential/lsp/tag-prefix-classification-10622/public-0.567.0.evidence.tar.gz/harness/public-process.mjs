import assert from 'node:assert/strict';
import {spawn,spawnSync} from 'node:child_process';
import {createHash} from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
const consumer=path.dirname(path.dirname(fileURLToPath(import.meta.url)));
const receiptPath=path.join(consumer,'provider.json');
const receiptBytes=fs.readFileSync(receiptPath),receipt=JSON.parse(receiptBytes);
const hash=bytes=>createHash('sha256').update(bytes).digest('hex');
const receiptSha256=hash(receiptBytes), captures=new WeakMap();
let sequence=0;
function verifiedProvider(){
 assert.equal(hash(fs.readFileSync(receiptPath)),receiptSha256);
 assert.equal(receipt.authority,'published-npm-consumer');
 assert.equal(process.platform,receipt.platform);assert.equal(process.arch,receipt.arch);
 for(const file of [receipt.provider.wrapper,receipt.provider.nativeAddon,receipt.dependencies.runtime]) {
  assert.equal(fs.realpathSync(file.path),file.path);
  assert.equal(hash(fs.readFileSync(file.path)),file.sha256);
 }
 const probe=spawnSync(receipt.provider.wrapper.path,['--version'],{encoding:'utf8'});
 assert.equal(probe.error,undefined);assert.equal(probe.signal,null);assert.equal(probe.status,0);assert.equal(probe.stdout.trim(),receipt.provider.cliVersion);
 return {exitStatus:probe.status,signal:probe.signal,stdout:probe.stdout,stderr:probe.stderr};
}
function directPublished(binding){
 assert.ok(binding,'explicit public binary binding is required');
 assert.equal(fs.realpathSync(binding.binary),receipt.provider.wrapper.path,'only the installed public executable can launch');
 assert.equal(binding.repoRoot,receipt.driver.sourceRoot);assert.equal(binding.published,undefined);
 const versionProbe=verifiedProvider();
 const directory=path.join(consumer,'raw',`session-${++sequence}`);fs.mkdirSync(directory,{recursive:true});
 const buffers={client:[],server:[],stderr:[]};
 const child=spawn(receipt.provider.wrapper.path,['lsp'],{cwd:binding.repoRoot,stdio:['pipe','pipe','pipe']});
 const metadata={schema:'vize.published.jsx-hover.raw-session',version:1,authority:'published-npm-consumer',providerReceiptSha256:receiptSha256,provider:receipt.provider,dependencies:receipt.dependencies,argv:['lsp'],cwd:binding.repoRoot,versionProbe,clientWireMeaning:'attempted-existing-LspSession-stdin-write',state:'running',streams:{},process:null};
 fs.writeFileSync(path.join(directory,'observation.json'),JSON.stringify(metadata,null,2)+'\n');
 captures.set(child,{buffers,directory});
 child.stdout.on('data',chunk=>buffers.server.push(Buffer.from(chunk)));
 child.stderr.on('data',chunk=>buffers.stderr.push(Buffer.from(chunk)));
 let error=null;child.on('error',reason=>{error=reason.message;});
 child.on('close',(code,signal)=>{
  for(const [name,parts]of Object.entries(buffers)){
   const bytes=Buffer.concat(parts);fs.writeFileSync(path.join(directory,`${name}.bin`),bytes);
   metadata.streams[name]={path:`${name}.bin`,capturedBytes:bytes.length,observedBytes:bytes.length,sha256:hash(bytes),truncated:false};
  }
  metadata.state='process-closed';metadata.process={exitStatus:code,signal,error};
  fs.writeFileSync(path.join(directory,'observation.json'),JSON.stringify(metadata,null,2)+'\n');
 });
 return child;
}
export function spawnBoundLspSessionProcess(binding){return directPublished(binding);}
export function spawnLspSessionProcess(){throw new Error('Unbound or source fallback spawning is forbidden in public acceptance');}
export function recordLspClientWire(child,frame){const capture=captures.get(child);assert.ok(capture);capture.buffers.client.push(Buffer.from(frame,'utf8'));}
