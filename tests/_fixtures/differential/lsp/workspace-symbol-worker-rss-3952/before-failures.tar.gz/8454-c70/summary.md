## Misskey LSP Churn Stress Oracle

Status: **failed**. Fixture: `misskey/packages/frontend@810faa8e5db4bbf9d6d408a61df148559340ee99`.

Churn cycles: 40 (broken -> repaired leaf and shared edits); min 255.5 ms, median 267.2 ms, max 282.0 ms (budget 9000 ms/cycle).

Diagnostics publishes observed: 287.

Peak server RSS: 128.3 MiB (budget 128 MiB). Peak process-tree RSS: 339.4 MiB (budget 384 MiB, max 3 processes).

Ceilings are enforced at scale 1 from the registry lspChurnBudget block; publish determinism, version ordering, stale-publish absence, and cancellation convergence are hard assertions.
