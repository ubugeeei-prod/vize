use std::sync::{
    Arc,
    atomic::{AtomicUsize, Ordering},
};

use futures::FutureExt;

use super::Worker;
use crate::runtime::block_on;

#[test]
fn navigation_worker_is_lazy_reuses_one_thread_and_keeps_inventory_owners_separate() {
    block_on(async {
        let worker = Worker::default();
        assert!(worker.sender.lock().await.is_none());
        let executor = std::thread::current().id();
        let first = worker.run(|| std::thread::current().id()).await.unwrap();
        assert_ne!(first, executor);
        for index in 0..40 {
            assert_eq!(
                worker
                    .run(move || (std::thread::current().id(), index))
                    .await,
                Some((first, index))
            );
        }
        let other = Worker::default();
        assert_ne!(other.run(|| std::thread::current().id()).await, Some(first));
    });
}

#[test]
fn overlapping_navigation_requests_run_once_on_one_existing_worker() {
    block_on(async {
        let worker = Worker::default();
        let active = Arc::new(AtomicUsize::new(0));
        let peak = Arc::new(AtomicUsize::new(0));
        let jobs = (0..40).map(|index| {
            let active = Arc::clone(&active);
            let peak = Arc::clone(&peak);
            worker.run(move || {
                let count = active.fetch_add(1, Ordering::SeqCst) + 1;
                peak.fetch_max(count, Ordering::SeqCst);
                std::thread::yield_now();
                active.fetch_sub(1, Ordering::SeqCst);
                (index, std::thread::current().id())
            })
        });
        let results = futures::future::join_all(jobs).await;
        let first = results[0].unwrap().1;
        assert_eq!(
            results,
            (0..40)
                .map(|index| Some((index, first)))
                .collect::<Vec<_>>()
        );
        assert_eq!(active.load(Ordering::SeqCst), 0);
        assert_eq!(peak.load(Ordering::SeqCst), 1);
    });
}

struct Release(Arc<AtomicUsize>);
impl Drop for Release {
    fn drop(&mut self) {
        self.0.fetch_add(1, Ordering::SeqCst);
    }
}

#[test]
fn cancelled_receiver_releases_its_work_and_preserves_the_worker_for_the_next_request() {
    block_on(async {
        let worker = Worker::default();
        let released = Arc::new(AtomicUsize::new(0));
        let owner = Release(Arc::clone(&released));
        let (entered, entering) = std::sync::mpsc::channel();
        let (resume, resuming) = std::sync::mpsc::channel();
        let mut request = Box::pin(worker.run(move || {
            let _owner = owner;
            let thread = std::thread::current().id();
            entered.send(thread).unwrap();
            resuming.recv().unwrap();
            thread
        }));
        assert!(request.as_mut().now_or_never().is_none());
        let first = entering
            .recv_timeout(std::time::Duration::from_secs(5))
            .unwrap();
        drop(request);
        assert_eq!(released.load(Ordering::SeqCst), 0);
        resume.send(()).unwrap();
        assert_eq!(
            worker.run(|| std::thread::current().id()).await,
            Some(first)
        );
        assert_eq!(released.load(Ordering::SeqCst), 1);
    });
}

#[test]
fn failed_native_work_returns_none_and_a_later_request_restarts_the_worker() {
    block_on(async {
        let worker = Worker::default();
        let first = worker.run(|| std::thread::current().id()).await.unwrap();
        assert_eq!(
            worker
                .run(|| panic!("intentional native worker failure"))
                .await,
            None::<()>
        );
        let next = worker.run(|| std::thread::current().id()).await.unwrap();
        assert_ne!(next, first);
        assert_eq!(worker.run(|| 42).await, Some(42));
    });
}
