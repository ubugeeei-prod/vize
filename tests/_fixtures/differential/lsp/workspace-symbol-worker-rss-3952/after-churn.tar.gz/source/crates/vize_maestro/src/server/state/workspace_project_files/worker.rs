//! Reuse the existing blocking navigation boundary across requests.

use futures::{
    SinkExt, StreamExt,
    channel::{mpsc, oneshot},
    lock::Mutex,
};

type Work = Box<dyn FnOnce() + Send + 'static>;

/// One lazy worker per inventory. The channel has one sender and no extra
/// buffer slots, so it retains at most one waiting command beside the running
/// command. Backpressure yields the LSP executor instead of spawning threads.
#[derive(Default)]
pub(super) struct Worker {
    sender: Mutex<Option<mpsc::Sender<Work>>>,
}

impl Worker {
    pub(super) async fn run<T: Send + 'static>(
        &self,
        work: impl FnOnce() -> T + Send + 'static,
    ) -> Option<T> {
        let mut sender = self.sender.lock().await;
        if sender.as_ref().is_none_or(mpsc::Sender::is_closed) {
            let (send, mut receive) = mpsc::channel::<Work>(0);
            if let Err(error) = std::thread::Builder::new()
                .name("vize-project-navigation".into())
                .spawn(move || {
                    crate::runtime::block_on(async {
                        while let Some(work) = receive.next().await {
                            work();
                        }
                    });
                })
            {
                tracing::warn!("failed to spawn project navigation discovery: {error}");
                return None;
            }
            *sender = Some(send);
        }
        let (result, receive) = oneshot::channel();
        let command: Work = Box::new(move || {
            let _ = result.send(work());
        });
        let sent = sender.as_mut()?.send(command).await;
        drop(sender);
        sent.ok()?;
        receive.await.ok()
    }
}

#[cfg(test)]
mod tests;
