## Misskey LSP Churn Stress Oracle

Status: **passed**. Fixture: `misskey/packages/frontend@810faa8e5db4bbf9d6d408a61df148559340ee99`.

Churn cycles: 40 (broken -> repaired leaf and shared edits); min 255.7 ms, median 266.9 ms, max 279.8 ms (budget 9000 ms/cycle).

Diagnostics publishes observed: 287.

Peak server RSS: 122.4 MiB (budget 128 MiB). Peak process-tree RSS: 341.5 MiB (budget 384 MiB, max 3 processes).

Ceilings are enforced at scale 1 from the registry lspChurnBudget block; publish determinism, version ordering, stale-publish absence, and cancellation convergence are hard assertions.
