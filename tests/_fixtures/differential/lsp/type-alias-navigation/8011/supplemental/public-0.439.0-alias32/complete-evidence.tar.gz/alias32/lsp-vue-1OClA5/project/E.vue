<script setup lang="ts">
type Props = {
  hidden?: boolean;
  tone?: "dark" | "light";
  html?: string;
};
const { html = "" } = defineProps<Props>();
</script>

<template>
  <span v-if="!hidden" :class="tone">x</span>
</template>
