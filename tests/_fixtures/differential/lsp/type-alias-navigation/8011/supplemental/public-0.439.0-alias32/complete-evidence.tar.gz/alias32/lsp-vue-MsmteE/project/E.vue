<script setup lang="ts">
type Props = {
  hidden?: boolean;
  tone?: "dark" | "light";
};
defineProps<Props>();
</script>

<template>
  <span v-if="!hidden" :class="tone">x</span>
</template>
