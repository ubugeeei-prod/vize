<script setup lang="ts">
type Props = {
  concealed?: boolean;
  tone?: "dark" | "light";
};
withDefaults(defineProps<Props>(), { tone: "light" });
</script>

<template>
  <span v-if="!concealed" :class="tone">x</span>
</template>
