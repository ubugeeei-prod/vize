<script setup lang="ts">
type Props = {
  hidden?: boolean;
  palette?: "dark" | "light";
};
withDefaults(defineProps<Props>(), { palette: "light" });
</script>

<template>
  <span v-if="!hidden" :class="palette">x</span>
</template>
