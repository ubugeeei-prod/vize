<script setup lang="ts">
const nativeGuard: number = 1;
</script>
<template>{{ nativeGuard }}</template>
