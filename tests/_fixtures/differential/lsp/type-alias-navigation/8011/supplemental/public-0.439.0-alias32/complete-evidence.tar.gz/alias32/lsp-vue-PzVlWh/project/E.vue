<script setup lang="ts">
type Props = {
  hidden?: boolean;
  palette?: "dark" | "light";
  html?: string;
};
const { html = "" } = defineProps<Props>();
</script>

<template>
  <span v-if="!hidden" :class="palette">x</span>
</template>
