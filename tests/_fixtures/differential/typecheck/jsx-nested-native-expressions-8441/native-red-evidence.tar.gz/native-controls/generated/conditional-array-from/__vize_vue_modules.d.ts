// Vue SFC modules resolve through materialized .vue.ts files.
