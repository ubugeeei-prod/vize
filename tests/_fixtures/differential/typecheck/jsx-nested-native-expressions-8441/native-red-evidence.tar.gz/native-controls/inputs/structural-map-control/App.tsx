const Host = (_props: any) => <div/>;
const ok = true;
const items = [0, 1, 2];
export const view = <Host>{{ content: () => <div>{items.map((i) => <p>{i}</p>)}</div> }}</Host>;
