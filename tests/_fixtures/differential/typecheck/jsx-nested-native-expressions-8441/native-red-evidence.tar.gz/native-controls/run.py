from pathlib import Path
import subprocess,json,hashlib,os,time
ROOT=Path(__file__).resolve().parent
SOURCE=Path('/Users/ubugeeei/Source/github.com/ubugeeei-prod/vize.fix-jsx-slot-parameter-annotations-20261010')
CLI=SOURCE/'target/debug/vize'
AUTH=Path('/private/tmp/vize-lsp439-20261010-fb402f3b')
NATIVE=AUTH/'public-consumer/node_modules/@typescript/typescript-darwin-arm64/lib/tsc'
NODE=Path('/Users/ubugeeei/.vite-plus/js_runtime/node/24.14.0/bin/node')
TS=AUTH/'original-vue/node_modules/typescript/bin/tsc'
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for block in iter(lambda:f.read(1048576),b''):h.update(block)
 return h.hexdigest()
def git(*args):return subprocess.check_output(['git',*args],cwd=SOURCE,text=True).strip()
assert git('status','--porcelain')==''
for key in ['VIZE_TS_RUNTIME_PATH','CORSA_PATH','VIZE_CORSA_PATH']:
 assert not os.environ.get(key),f'nonempty initial runtime override: {key}'
identities={name:{'path':str(path),'realpath':str(path.resolve()),'sha256':sha(path)} for name,path in [('sourceCli',CLI),('publicNative',NATIVE),('node',NODE),('typescript',TS)]}
assert identities['publicNative']['sha256']=='a82f731365ad69d5c4c15f5e18fba4584bf3b7b839960172a76c3462b5114bf2'
assert identities['node']['sha256']=='20a18709f0154d668f1bd6f6ea8c2a7ae001447b4b2c339732f22e57a8767a55'
cases={
 'conditional-array-from':'ok ? <p/> : Array.from({ length: 3 }, (_, i) => <p>{i}</p>)',
 'raw-array-from':'Array.from({ length: 3 }, (_, i) => <p>{i}</p>)',
 'structural-map-control':'items.map((i) => <p>{i}</p>)',
}
records=[]
for name,expression in cases.items():
 project=ROOT/'inputs'/name;project.mkdir(parents=True)
 (project/'node_modules').symlink_to(AUTH/'original-vue/node_modules',target_is_directory=True)
 source='const Host = (_props: any) => <div/>;\nconst ok = true;\nconst items = [0, 1, 2];\nexport const view = <Host>{{ content: () => <div>{'+expression+'}</div> }}</Host>;\n'
 (project/'App.tsx').write_text(source)
 config={'compilerOptions':{'strict':True,'target':'ES2022','module':'ESNext','moduleResolution':'bundler','jsx':'preserve','jsxImportSource':'vue','types':['vue/jsx'],'noEmit':True},'files':['App.tsx']}
 (project/'tsconfig.json').write_text(json.dumps(config,indent=2)+'\n')
 (project/'vize.config.json').write_text('{"typeChecker":{"jsxTypecheck":true}}\n')
 input_hashes={file:sha(project/file) for file in ['App.tsx','tsconfig.json','vize.config.json']}
 for producer,argv in [('stock-ts6',[str(NODE),str(TS),'--project','tsconfig.json','--pretty','false']),('public-native7',[str(NATIVE),'--project','tsconfig.json','--pretty','false']),('source-parent8428',[str(CLI),'check','App.tsx','--quiet','--format','json','--corsa-path',str(NATIVE)])]:
  raw=ROOT/'raw'/f'{name}-{producer}';raw.mkdir(parents=True)
  start=time.monotonic_ns(); result=subprocess.run(argv,cwd=project,capture_output=True,timeout=90);elapsed=time.monotonic_ns()-start
  (raw/'stdout').write_bytes(result.stdout);(raw/'stderr').write_bytes(result.stderr)
  record={'case':name,'producer':producer,'argv':argv,'cwd':str(project),'status':result.returncode,'elapsedNs':elapsed,'stdoutSha256':sha(raw/'stdout'),'stderrSha256':sha(raw/'stderr'),'inputs':input_hashes,'expectedOriginalDiagnostics':[],'expectedSourceCliDiagnostics':[]}
  if producer=='source-parent8428':record['report']=json.loads(result.stdout)
  else:
   assert result.returncode==0 and result.stdout==b'' and result.stderr==b'',(name,producer,result.returncode,result.stdout,result.stderr)
  assert input_hashes=={file:sha(project/file) for file in input_hashes}
  (raw/'execution.json').write_text(json.dumps(record,indent=2)+'\n');records.append(record)
for name,path in [('sourceCli',CLI),('publicNative',NATIVE),('node',NODE),('typescript',TS)]:assert identities[name]['sha256']==sha(path)
assert git('status','--porcelain')==''
receipt={'schema':1,'sourceCheckout':str(SOURCE),'sourceHead':git('rev-parse','HEAD'),'sourceStatus':'clean','identities':identities,'publicAuthorityReceipt':str(AUTH/'receipts/public-authority.json'),'publicAuthorityReceiptSha256':sha(AUTH/'receipts/public-authority.json'),'originalVueAuthorityRoot':str(AUTH/'original-vue'),'runtimeSelection':'explicit public native binary via --corsa-path; original native process separately executed; no signature-verification claim','records':records}
(ROOT/'results.json').write_text(json.dumps(receipt,indent=2)+'\n')
print('receipt',ROOT/'results.json','sha256',sha(ROOT/'results.json'))
for record in records:
 if record['producer']=='source-parent8428':print(record['case'],'status',record['status'],'errors',record['report']['errorCount'],'files',record['report']['files'])
