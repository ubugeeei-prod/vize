import datetime, hashlib, json, os, pathlib, subprocess, sys, tarfile, io

SOURCE = pathlib.Path('<USER_HOME>/Source/github.com/ubugeeei-prod/vize.repair-lsp-event-slot-stack8301-20261010')
BASE = pathlib.Path('<LOCAL_TMP>/vize-lsp441-20261010-bb83dd98')
NODE = pathlib.Path('<USER_HOME>/.vite-plus/js_runtime/node/24.14.0/bin/node')
NPM = pathlib.Path('<USER_HOME>/.vite-plus/js_runtime/node/24.14.0/lib/node_modules/npm/bin/npm-cli.js')
C = '61e0e3309a85dcb319fd5133d36c7d7f4f44964f'
H = 'bb83dd9817837ab4a87b09b32646389fb570a705'
T = 'b151dee0aae7a6e69df459ee34092eb61122ed61'
M = '9c9ffb8bea95f75bfc7d148e63d5da76b02e7a33'
R = 38037918678
AUTH = 'a26411442a3fde2590d969160fd83b97685e9019d2de4decb0c103a376f10786'
KEYS = ['NODE_OPTIONS','VIZE_PREFER_WORKSPACE_BINDING','NAPI_RS_NATIVE_LIBRARY_PATH','NAPI_RS_FORCE_WASI','VIZE_ALLOW_NATIVE_VERSION_MISMATCH','CORSA_PATH','CORSA_EXECUTABLE','TSGO_PATH','TSGO_EXECUTABLE','VIZE_PUBLIC_NATIVE_CUSTODY','VIZE_OXLINT_NATIVE_CUSTODY']
assert all(not os.environ.get(key) for key in KEYS), 'initial source/runtime override is nonempty'
def sha(data): return hashlib.sha256(data).hexdigest()
assert sha(NODE.read_bytes()) == '20a18709f0154d668f1bd6f6ea8c2a7ae001447b4b2c339732f22e57a8767a55'
assert sha(NPM.read_bytes()) == '8e5f6f3429f8cdbe693cdc29904e9d5a7b127a494bd15c804bd54c7403bfcbe7'
assert NODE.resolve(strict=True) == NODE and NPM.resolve(strict=True) == NPM
seal_path = pathlib.Path('<SYSTEM_TMP>/vize-0441-terminal-canonical-publication-review.json')
seal_bytes = seal_path.read_bytes()
assert sha(seal_bytes) == 'f0f2f6b0059db36174611ca53c8b99e222c86f39da54341ec44024c340e6922b'
seal = json.loads(seal_bytes)
assert seal['source']['C'] == C and seal['source']['H'] == H and seal['source']['releaseRun'] == R and seal['source']['sourcePr'] == 8473 and seal['source']['tagObject'] == T
assert seal['metadata']['merge'] == M and seal['metadata']['signedMergeVerified'] is True
authority_bytes = subprocess.check_output(['python3','-I',str(SOURCE/'tools/support/release/public_install/collect.py'),'--print-collector-authority'])
authority = json.loads(authority_bytes)
assert authority['sha256'] == AUTH and len(authority['files']) == 8
for item in authority['files']:
    path = SOURCE/item['path']
    assert path.resolve(strict=True) == path and sha(path.read_bytes()) == item['sha256']
def git(*args): return subprocess.check_output(['git','-C',str(SOURCE),*args]).decode().strip()
assert git('rev-parse',H+'^') == C
assert git('rev-parse','v0.441.0') == T and git('rev-parse',T+'^{}') == H
run_bytes = subprocess.check_output(['gh','api',f'repos/ubugeeei-prod/vize/actions/runs/{R}/attempts/2'])
run = json.loads(run_bytes)
assert run['status'] == 'completed' and run['conclusion'] == 'success' and run['head_sha'] == H and run['run_attempt'] == 2
BASE.mkdir()
assert BASE.resolve(strict=True) == BASE
receipts = BASE/'receipts'
receipts.mkdir()
install = BASE/'public-consumer'
install.mkdir()
(receipts/'terminal-publication-seal.json').write_bytes(seal_bytes)
(receipts/'terminal-release-run.json').write_bytes(run_bytes)
(receipts/'reviewed-collector-authority.json').write_bytes(authority_bytes)
snapshot = receipts/'reviewed-collector-snapshot.tar.gz'
with tarfile.open(snapshot,'w:gz') as tar:
    for item in authority['files']:
        content = (SOURCE/item['path']).read_bytes()
        info = tarfile.TarInfo(item['path']); info.size=len(content); info.mode=0o644; info.mtime=0; info.uid=info.gid=0
        tar.addfile(info,io.BytesIO(content))
deps = {name:'0.441.0' for name in ['vize','oxlint-plugin-vize','@vizejs/native','@vizejs/native-darwin-arm64']}
(install/'package.json').write_text(json.dumps({'name':'vize-lsp441-authenticated-consumer','private':True,'dependencies':deps},indent=2)+'\n')
env = dict(os.environ)
env['PATH'] = str(NODE.parent) + ':<USER_HOME>/.rustup/toolchains/1.99.0-aarch64-apple-darwin/bin:<USER_HOME>/.cargo/bin:' + env['PATH']
env['RUSTC'] = '<USER_HOME>/.rustup/toolchains/1.99.0-aarch64-apple-darwin/bin/rustc'
env['RUSTDOC'] = '<USER_HOME>/.rustup/toolchains/1.99.0-aarch64-apple-darwin/bin/rustdoc'
npm_argv = [str(NODE),str(NPM),'install','--ignore-scripts','--registry=https://registry.npmjs.org','--cache',str(BASE/'npm-cache')]
with (receipts/'npm-install.stdout').open('xb') as out, (receipts/'npm-install.stderr').open('xb') as err:
    result = subprocess.run(npm_argv,cwd=install,env=env,stdout=out,stderr=err)
packet={'schema':'vize-public-install-launch-v1','checkedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source':seal['source'],'metadata':seal['metadata'],'terminalSealSha256':sha(seal_bytes),'terminalRunSha256':sha(run_bytes),'collectorSha256':AUTH,'collectorSnapshotPath':str(snapshot),'collectorSnapshotArchiveSha256':sha(snapshot.read_bytes()),'sourceOverrides':{key:'' for key in KEYS},'nodeSha256':sha(NODE.read_bytes()),'npmSha256':sha(NPM.read_bytes()),'npmArgv':npm_argv,'npmExitCode':result.returncode,'npmStdoutSha256':sha((receipts/'npm-install.stdout').read_bytes()),'npmStderrSha256':sha((receipts/'npm-install.stderr').read_bytes())}
(receipts/'launch.json').write_text(json.dumps(packet,indent=2)+'\n')
assert result.returncode == 0, 'public npm installation failed; whole raw streams retained'
assert all(not os.environ.get(key) for key in KEYS)
args=['<USER_HOME>/.cargo/bin/rust-script',str(SOURCE/'tools/commands/release/npm/collect-public-install.rs'),'--root',str(SOURCE),'--cut',C,'--head',H,'--tag','v0.441.0','--run',str(R),'--install-root',str(install),'--node',str(NODE),'--output',str(receipts/'public-authority.json'),'--collector-sha256',AUTH]
(receipts/'collector-argv.json').write_text(json.dumps(args,indent=2)+'\n')
print(json.dumps({'phase':'installed; launching single official collector','root':str(install),'receipt':str(receipts/'public-authority.json')}),flush=True)
with (receipts/'collector.stdout').open('xb') as out, (receipts/'collector.stderr').open('xb') as err:
    result=subprocess.run(args,cwd=SOURCE,env=env,stdout=out,stderr=err)
print(json.dumps({'phase':'collector finished','exitCode':result.returncode,'root':str(install),'receipt':str(receipts/'public-authority.json'),'receiptSha256':sha((receipts/'public-authority.json').read_bytes()) if (receipts/'public-authority.json').exists() else None}),flush=True)
sys.exit(result.returncode)
