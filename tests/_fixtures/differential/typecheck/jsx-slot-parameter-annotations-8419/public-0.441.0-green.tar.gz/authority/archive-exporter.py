import gzip,hashlib,io,json,pathlib,subprocess,tarfile

WT=pathlib.Path('<USER_HOME>/Source/github.com/ubugeeei-prod/vize.test-jsx-installed-slot-parameters-8419-20261010')
SOURCE=pathlib.Path('<USER_HOME>/Source/github.com/ubugeeei-prod/vize.repair-lsp-event-slot-stack8301-20261010')
BASE=pathlib.Path('<LOCAL_TMP>/vize-lsp441-20261010-bb83dd98/receipts')
CAMPAIGN=pathlib.Path('<LOCAL_TMP>/vize-jsx8419-installed-green-20261010-v0441')
FIXTURE=WT/'tests/_fixtures/differential/typecheck/jsx-slot-parameter-annotations-8419'
def sha(data):return hashlib.sha256(data).hexdigest()
data={}
def add(name,path):
    assert name not in data and not name.startswith('/') and '..' not in pathlib.PurePosixPath(name).parts
    path=pathlib.Path(path);assert path.resolve(strict=True)==path
    data[name]=path.read_bytes()
r=json.loads((CAMPAIGN/'receipt.json').read_bytes())
assert r['success'] is True and len(r['cases'])==9 and all(c['success'] for c in r['cases'])
add('campaign/receipt.json',CAMPAIGN/'receipt.json')
for case in r['cases']:
    for f in case['files']:
        path=CAMPAIGN/f['path'];assert path.stat().st_size==f['size'] and sha(path.read_bytes())==f['sha256']
        add('campaign/'+f['path'],path)
for name in ['public-authority.json','public-authority.json.public-payload-files.json','public-authority.json.native-journal.jsonl','reviewed-collector-authority.json','reviewed-collector-snapshot.tar.gz','launch.json','collector-argv.json','collector.stdout','collector.stderr','npm-install.stdout','npm-install.stderr','terminal-publication-seal.json','terminal-release-run.json','independent-custody-review.json','child-independent-review.json','finite-install-custody-seal.json','jsx8419-launch.json','jsx8419-green.stdout','jsx8419-green.stderr']:
    add('authority/'+name,BASE/name)
add('authority/install-launcher.py','<LOCAL_TMP>/vize-lsp441-official-launch-20261010.py')
add('authority/acceptance-launcher.py','<LOCAL_TMP>/vize-jsx8419-launch-installed-green-441.py')
add('authority/acceptance-runner.mjs','<LOCAL_TMP>/vize-jsx8419-installed-green-20261010.mjs')
add('authority/red-archive-verifier.mjs','<LOCAL_TMP>/vize-jsx8419-red-archive-custody-20261010.mjs')
add('authority/archive-exporter.py',__file__)
add('authority/whole-payload-auditor.py','<LOCAL_TMP>/vize-lsp441-independent-custody-audit-20261010.py')
add('authority/original-vue-receipt.json','<LOCAL_TMP>/vize-lsp439-20261010-fb402f3b/original-vue/receipt.json')
for name in ['source-pr8428.json','source-merge-cdc31c19.json']:
    add('authority/'+name,pathlib.Path('<LOCAL_TMP>/vize-jsx8419-installed-acceptance-preparation-20261010')/name)
closure_path=pathlib.Path('<LOCAL_TMP>/vize-lsp440-20261010-5998a437/receipts/runner-module-closure.json')
add('authority/runner-module-closure.json',closure_path)
closure=json.loads(closure_path.read_bytes())
for f in closure['files']:
    assert sha((SOURCE/f['path']).read_bytes())==f['sha256']
    add('runner-source/'+f['path'],SOURCE/f['path'])
authority=json.loads((BASE/'public-authority.json').read_bytes())
for f in authority['collectorAuthority']['files']:
    assert sha((SOURCE/f['path']).read_bytes())==f['sha256']
    add('collector-source/'+f['path'],SOURCE/f['path'])
for name in ['cases.json','Child.vue.txt',*[c['id']+'.tsx.txt' for c in r['cases']]]:
    literal=subprocess.check_output(['git','-C',str(SOURCE),'show','4e7ac99e1a6293903471f49818fb7f7fba46b2d0:tests/_fixtures/differential/typecheck/jsx-slot-parameter-annotations-8419/'+name])
    assert (FIXTURE/name).read_bytes()==literal
    data['authored-inputs/'+name]=literal
archive=FIXTURE/'public-0.441.0-green.tar.gz'
if archive.exists():
    assert sha(archive.read_bytes())=='b347b4792f7e12d613c3de79bd97ee397a78ef9974f07687b0c23df507e0ab9d'
    archive.unlink()
with archive.open('xb') as out:
    with gzip.GzipFile(filename='',mode='wb',fileobj=out,mtime=0) as gz:
        with tarfile.open(fileobj=gz,mode='w') as tar:
            for name,content in sorted(data.items()):
                info=tarfile.TarInfo(name);info.size=len(content);info.mode=0o644;info.uid=info.gid=0;info.mtime=0
                tar.addfile(info,io.BytesIO(content))
with tarfile.open(archive) as tar:
    members=tar.getmembers();assert len(members)==len(data)
    for member in members:assert member.isfile() and tar.extractfile(member).read()==data[member.name]
manifest={'schema':'vize-installed-jsx-slot-green-corpus-v1','issue':8419,'source':r['source'],'releaseSourcePr':8473,'releaseSourcePrMerged':False,'signedSourceMerge':r['signedSourceMerge'],'fixtureSourceHead':r['fixtureSourceHead'],'scope':r['scope'],'publicReceiptSha256':r['publicReceiptSha256'],'collectorSha256':authority['collectorAuthority']['sha256'],'finiteInstallSealSha256':sha((BASE/'finite-install-custody-seal.json').read_bytes()),'historicalRed':{'archive':'public-0.439.0-red.tar.gz','sha256':sha((FIXTURE/'public-0.439.0-red.tar.gz').read_bytes()),'unchangedOriginalInputs':True},'cases':[{'id':c['id'],'exitCode':c['process']['exitCode'],'nativePid':c['process']['pid'],'nativeJournalSha256':c['nativeJournalSha256'],'wholeAuthoredPacketEqual':True} for c in r['cases']],'archive':{'path':archive.name,'bytes':archive.stat().st_size,'sha256':sha(archive.read_bytes()),'regularFiles':len(data)},'members':[{'path':name,'bytes':len(content),'sha256':sha(content)} for name,content in sorted(data.items())],'npmUserGlobalConfigFilesInspectedOrHashed':False,'cryptographicProvenanceSignatureVerificationPerformed':False,'installedSourceMapApiClaimed':False,'broaderDefaultLspPerformanceOrContractsQualified':False,'success':True}
p=FIXTURE/'public-0.441.0-green-manifest.json';p.write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'archive':str(archive),'archiveSha256':manifest['archive']['sha256'],'bytes':archive.stat().st_size,'regularFiles':len(data),'manifest':str(p),'manifestSha256':sha(p.read_bytes()),'receiptSha256':sha((CAMPAIGN/'receipt.json').read_bytes())}))
