import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import {spawnSync} from 'node:child_process';
import {authenticateRedArchive} from '<LOCAL_TMP>/vize-jsx8419-red-archive-custody-20261010.mjs';
import {loadPublicAuthority,recheckPublicBytes} from '<USER_HOME>/Source/github.com/ubugeeei-prod/vize.repair-lsp-event-slot-stack8301-20261010/tests/tooling/support/lsp/installed-alias-replay/authority.ts';
import {publicEnvironment} from '<USER_HOME>/Source/github.com/ubugeeei-prod/vize.repair-lsp-event-slot-stack8301-20261010/tests/tooling/support/lsp/installed-alias-replay/custody.ts';
import {loadVueFixtureAuthority} from '<USER_HOME>/Source/github.com/ubugeeei-prod/vize.repair-lsp-event-slot-stack8301-20261010/tests/tooling/support/lsp/installed-alias-replay/vue.ts';
import {RawGitRepository} from '<USER_HOME>/Source/github.com/ubugeeei-prod/vize.repair-lsp-event-slot-stack8301-20261010/tests/tooling/support/lsp/installed-alias-replay/raw-git.ts';
const repo='<USER_HOME>/Source/github.com/ubugeeei-prod/vize.repair-lsp-event-slot-stack8301-20261010';
const prep='<LOCAL_TMP>/vize-jsx8419-installed-acceptance-preparation-20261010';
const fixtureHead='4e7ac99e1a6293903471f49818fb7f7fba46b2d0';
const fixture='tests/_fixtures/differential/typecheck/jsx-slot-parameter-annotations-8419';
const sourceMerge='cdc31c192503b992dc9568e81ebae5cd0aa7c696';
const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
const args=new Map();
for(let i=2;i<process.argv.length;i+=2){assert.ok(['--authority','--authority-sha256','--output'].includes(process.argv[i]));assert.ok(process.argv[i+1]&&!args.has(process.argv[i]));args.set(process.argv[i],process.argv[i+1]);}
assert.equal(args.size,3);
const sourceRecords=[['source-pr8428.json','024c71d673c8f4f942e092df9a7bba93a24c3627570f35ae8cd5d26945da9cd9'],['source-merge-cdc31c19.json','8f7ba4ee045c90911fb72320c1d685661b5c620d329ba1855063f21ceaa64177']].map(([name,digest])=>{const bytes=fs.readFileSync(path.join(prep,name));assert.equal(sha(bytes),digest);return JSON.parse(bytes);});
const [pr,commit]=sourceRecords;
assert.equal(pr.number,8428);assert.equal(pr.html_url,'https://github.com/ubugeeei-prod/vize/pull/8428');assert.equal(pr.merged,true);assert.equal(pr.base.ref,'main');assert.equal(pr.base.repo.full_name,'ubugeeei-prod/vize');assert.equal(pr.merge_commit_sha,sourceMerge);assert.equal(pr.head.sha,fixtureHead);
assert.equal(commit.sha,sourceMerge);assert.equal(commit.html_url,'https://github.com/ubugeeei-prod/vize/commit/'+sourceMerge);assert.equal(commit.commit.verification.verified,true);assert.equal(commit.commit.verification.reason,'valid');
const raw=new RawGitRepository(repo);const input=name=>raw.file(fixtureHead,fixture+'/'+name);
const cases=JSON.parse(input('cases.json')).cases;const historical=authenticateRedArchive(raw,fixtureHead,fixture,cases);
const authority=loadPublicAuthority(args.get('--authority'),args.get('--authority-sha256'),repo,sourceMerge);
assert.equal(authority.version,'0.441.0');assert.deepEqual(authority.source,{C:'61e0e3309a85dcb319fd5133d36c7d7f4f44964f',H:'bb83dd9817837ab4a87b09b32646389fb570a705',tag:'v0.441.0',R:'38037918678'});
const authorityBytes=fs.readFileSync(args.get('--authority'));const runnerSha256=sha(fs.readFileSync(new URL(import.meta.url)));const redVerifierSha256=sha(fs.readFileSync('<LOCAL_TMP>/vize-jsx8419-red-archive-custody-20261010.mjs'));
const closureBytes=fs.readFileSync('<LOCAL_TMP>/vize-lsp440-20261010-5998a437/receipts/runner-module-closure.json');assert.equal(sha(closureBytes),'08665030f1120b8e28402ee98188b71884b6eeb76ad244b5328511e0ddf1dc54');const closure=JSON.parse(closureBytes);assert.equal(closure.sourceHead,'076fa3f25adf2feb249bdbdff3aa16d3f9e9dfa0');assert.equal(closure.files.length,30);
const runnerFiles=closure.files.map(row=>{const file=path.join(repo,row.path);assert.equal(sha(raw.file(closure.sourceHead,row.path)),row.sha256);assert.equal(sha(fs.readFileSync(file)),row.sha256);return {path:file,sha256:row.sha256};});
const priorCollectorBytes=fs.readFileSync('<LOCAL_TMP>/vize-lsp440-20261010-5998a437/receipts/public-authority.json');assert.equal(sha(priorCollectorBytes),'ad20350f3e7e9d644e311abba179c6f7f61fa0cef8e9a3a9655cfb017fb35ce3');const approvedCollector=JSON.parse(priorCollectorBytes).collectorAuthority;assert.equal(approvedCollector.sha256,'a26411442a3fde2590d969160fd83b97685e9019d2de4decb0c103a376f10786');assert.deepEqual(authority.collectorAuthority,approvedCollector);
const vue=loadVueFixtureAuthority({receiptPath:'<LOCAL_TMP>/vize-lsp439-20261010-fb402f3b/original-vue/receipt.json',receiptSha256:'8f1ec3f613e8d36ac6efead9aacbaf60feccbe0f74b490dd2c6557c3f86c300a',sourceRoot:repo,sourceHead:'c2bc3a55a2b70dc4dd6c4e43ee0737c347476398'});
const root=args.get('--output');assert.ok(path.isAbsolute(root)&&!fs.existsSync(root));assert.equal(path.resolve(root),root);assert.equal(fs.realpathSync(path.dirname(root)),path.dirname(root));
for(const owner of [authority.installRoot,repo,vue.receipt.installRoot,prep]){const relative=path.relative(owner,root);assert.ok(relative==='..'||relative.startsWith('..'+path.sep)||path.isAbsolute(relative),'output must remain outside immutable installation/source/fixture roots');const reverse=path.relative(root,owner);assert.ok(reverse==='..'||reverse.startsWith('..'+path.sep)||path.isAbsolute(reverse),'output cannot contain immutable owned roots');}
fs.mkdirSync(root);assert.equal(fs.realpathSync(root),root);
const sourceInputs=new Map();
const options={jsx:'preserve',module:'ESNext',moduleResolution:'Bundler',skipLibCheck:true,strict:true,target:'ES2022',types:['vue/jsx']};
const outcomes=[];
const writeReceipt=success=>fs.writeFileSync(path.join(root,'receipt.json'),JSON.stringify({schema:'vize-installed-jsx-slot-contract-v1',scope:'nine whole original check CLI diagnostic packets; no installed source-map API claim',source:authority.source,releaseSourcePr:8473,collectorAuthority:approvedCollector,runnerClosureSha256:sha(closureBytes),runnerSha256,redVerifierSha256,runnerFiles,historicalBefore:historical.record,sourcePr:8428,signedSourceMerge:sourceMerge,fixtureSourceHead:fixtureHead,publicReceiptSha256:args.get('--authority-sha256'),originalVueReceiptSha256:'8f1ec3f613e8d36ac6efead9aacbaf60feccbe0f74b490dd2c6557c3f86c300a',cases:outcomes,success},null,2)+'\n');
writeReceipt(false);
for(const test of cases){
 recheckPublicBytes(authority);vue.recheck();const cwd=path.join(root,test.id);fs.mkdirSync(cwd);fs.symlinkSync(path.dirname(vue.vuePath),path.join(cwd,'node_modules'));
 const child=input('Child.vue.txt'),consumer=input(test.id+'.tsx.txt');fs.writeFileSync(path.join(cwd,'Child.vue'),child);fs.writeFileSync(path.join(cwd,'Consumer.tsx'),consumer);
 fs.writeFileSync(path.join(cwd,'vize.config.json'),'{"typeChecker":{"jsxTypecheck":true}}\n');
 fs.writeFileSync(path.join(cwd,'tsconfig.json'),JSON.stringify({compilerOptions:{strict:true,target:'ES2022',module:'ESNext',moduleResolution:'Bundler',jsx:'preserve',skipLibCheck:true,types:['vue/jsx']},include:['*.vue','*.tsx']}));
 const authoredInputs=new Map(['Child.vue','Consumer.tsx','tsconfig.json','vize.config.json'].map(name=>[name,fs.readFileSync(path.join(cwd,name))]));sourceInputs.set(test.id,authoredInputs);
 if(historical.record.historicalCases.includes(test.id))for(const [name,bytes] of authoredInputs)assert.deepEqual(bytes,historical.files.get(test.id+'/'+name),'same original public RED input '+test.id+'/'+name);
 const vueLinkTarget=fs.realpathSync(path.join(cwd,'node_modules'));assert.equal(vueLinkTarget,path.dirname(vue.vuePath));
 const journalPath=path.join(cwd,'native-journal.ndjson');const argv=['--require',authority.custodyHook.path,authority.cli.binPath,'check','Consumer.tsx','Child.vue','--format','json','--quiet'];
 const result=spawnSync(authority.node.path,argv,{cwd,env:publicEnvironment(authority,journalPath),encoding:'utf8',timeout:120000,maxBuffer:16*1024*1024});
 const processRecord={node:authority.node,argv,cwd,pid:result.pid,exitCode:result.status,signal:result.signal,error:result.error?.message??null};
 fs.writeFileSync(path.join(cwd,'stdout.raw'),result.stdout??'');fs.writeFileSync(path.join(cwd,'stderr.raw'),result.stderr??'');fs.writeFileSync(path.join(cwd,'process.json'),JSON.stringify(processRecord,null,2)+'\n');
 const expected={files:[{file:'Child.vue',diagnostics:[]},{file:'Consumer.tsx',diagnostics:test.diagnostics}],programs:[{root:'.',tsconfig:'tsconfig.json',compilerOptions:options,files:['Child.vue','Consumer.tsx','node_modules/vue/jsx.d.ts']}],errorCount:test.diagnostics.length,warningCount:0,fileCount:2};
 fs.writeFileSync(path.join(cwd,'expected-report.json'),JSON.stringify(expected,null,2)+'\n');
 const observation={id:test.id,process:processRecord,expectedReport:expected,actualReport:null,success:false};
 try{
  assert.equal(result.error,undefined);assert.equal(result.signal,null);assert.equal(result.status,test.exitCode);assert.equal(result.stderr,'');
  const bytes=fs.readFileSync(journalPath);assert.ok(bytes.length&&bytes.at(-1)===10);const events=bytes.toString('utf8').trimEnd().split('\n').map(line=>JSON.parse(line));
  assert.equal(events[0].event,'initialized');assert.equal(events[0].node,authority.node.path);assert.deepEqual(events[0].argv,[authority.node.path,authority.cli.binPath,...argv.slice(3)]);assert.equal(events[0].installRoot,authority.installRoot);assert.equal(events[0].nativePath,authority.native.path);assert.equal(events[0].sha256,authority.native.sha256);
  for(const event of events){assert.equal(event.schema,'vize-public-native-custody-event-v1');assert.equal(event.pid,result.pid);assert.ok(['initialized','attempt','returned','exit'].includes(event.event));}
  const native=events.filter(event=>event.expectedNative===true);assert.deepEqual(native.map(event=>event.event),['attempt','returned']);
  for(const event of native){assert.equal(event.actualPath,authority.native.path);assert.equal(event.sha256,authority.native.sha256);assert.equal(event.corsaPath,authority.bundledCorsa.path);}
  const exits=events.filter(event=>event.event==='exit');assert.ok(exits.length<=1);if(result.status===0)assert.equal(exits.length,1);if(exits.length)assert.equal(exits[0].code,result.status);
  observation.actualReport=JSON.parse(result.stdout);assert.deepEqual(observation.actualReport,expected);
  for(const [name,bytes] of authoredInputs)assert.deepEqual(fs.readFileSync(path.join(cwd,name)),bytes);assert.equal(fs.realpathSync(path.join(cwd,'node_modules')),vueLinkTarget);recheckPublicBytes(authority);vue.recheck();assert.deepEqual(fs.readFileSync(args.get('--authority')),authorityBytes);for(const file of runnerFiles)assert.equal(sha(fs.readFileSync(file.path)),file.sha256);assert.equal(sha(fs.readFileSync(new URL(import.meta.url))),runnerSha256);assert.equal(sha(fs.readFileSync('<LOCAL_TMP>/vize-jsx8419-red-archive-custody-20261010.mjs')),redVerifierSha256);observation.nativeJournalSha256=sha(bytes);observation.success=true;
 }catch(error){observation.failure=String(error?.stack??error);}
 observation.files=['Child.vue','Consumer.tsx','tsconfig.json','vize.config.json','stdout.raw','stderr.raw','process.json','expected-report.json',...(fs.existsSync(journalPath)?['native-journal.ndjson']:[])].map(name=>{const b=fs.readFileSync(path.join(cwd,name));return {path:test.id+'/'+name,size:b.length,sha256:sha(b)};});outcomes.push(observation);writeReceipt(false);
}
recheckPublicBytes(authority);vue.recheck();assert.deepEqual(fs.readFileSync(args.get('--authority')),authorityBytes);for(const row of outcomes){for(const [name,bytes] of sourceInputs.get(row.id))assert.deepEqual(fs.readFileSync(path.join(root,row.id,name)),bytes);for(const file of row.files){const b=fs.readFileSync(path.join(root,file.path));assert.equal(b.length,file.size);assert.equal(sha(b),file.sha256);}}assert.deepEqual(authenticateRedArchive(raw,fixtureHead,fixture,cases).record,historical.record);assert.equal(outcomes.length,9);assert.ok(outcomes.every(row=>row.success),outcomes.filter(row=>!row.success).map(row=>row.id+': '+row.failure).join('\n'));
writeReceipt(true);process.stdout.write(JSON.stringify({source:authority.source,completed:9,success:true,output:root})+'\n');
