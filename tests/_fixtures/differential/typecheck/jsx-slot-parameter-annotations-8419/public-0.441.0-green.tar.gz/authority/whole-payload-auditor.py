import hashlib, json, pathlib, base64, tarfile
BASE=pathlib.Path('<LOCAL_TMP>/vize-lsp441-20261010-bb83dd98')
SOURCE=pathlib.Path('<USER_HOME>/Source/github.com/ubugeeei-prod/vize.repair-lsp-event-slot-stack8301-20261010')
def sha(data): return hashlib.sha256(data).hexdigest()
def read(path, expected=None):
    path=pathlib.Path(path)
    assert path.resolve(strict=True)==path
    data=path.read_bytes()
    if expected: assert sha(data)==expected,str(path)
    return data
receipt=BASE/'receipts/public-authority.json'
r=json.loads(read(receipt,'d9a29f1029bbd386b722d7ddbcc5fe876649050fdf78c19bd913b193eb29557b'))
assert r['success'] is True and r['source']=={'C':'61e0e3309a85dcb319fd5133d36c7d7f4f44964f','H':'bb83dd9817837ab4a87b09b32646389fb570a705','tag':'v0.441.0','R':'38037918678'}
install=pathlib.Path(r['installRoot']); assert install==BASE/'public-consumer'
lock=json.loads(read(r['packageLockPath'],r['packageLockSha256']))
expected={n:'0.441.0' for n in ['vize','oxlint-plugin-vize','@vizejs/native','@vizejs/native-darwin-arm64']}
assert lock['lockfileVersion']==3 and lock['packages']['']['dependencies']==expected
consumer=json.loads(read(install/'package.json'));assert consumer['private'] is True and consumer['dependencies']==expected
m=json.loads(read(r['payloadManifestPath'],r['payloadManifestSha256']))
assert m['source']==r['source'] and m['installRoot']==r['installRoot']
counts=[]
for p in m['packages']:
    owner=pathlib.Path(p['packageDirectory']);assert owner==install/'node_modules'/p['name']
    actual=set(f for f in owner.rglob('*') if f.is_file())
    declared=set(pathlib.Path(f['path']) for f in p['files'])
    assert actual==declared and len(declared)==len(p['files'])==p['fileCount'],p['name']
    for f in p['files']:
        path=pathlib.Path(f['path']);assert owner in path.parents
        content=read(path,f['sha256']);assert len(content)==f['bytes']
    entry=lock['packages']['node_modules/'+p['name']]
    assert entry['version']==p['version'] and entry['resolved']==p['resolved'] and entry['integrity']==p['integrity'] and entry.get('link') is not True
    assert base64.b64decode(p['integrity'].split('-',1)[1]).hex()==p['tarballSHA512']
    if p['name'] in expected:
        proof=p['provenancePayloadBinding'];assert proof['payloadBindingChecked'] is True and proof['cryptographicSignatureVerificationPerformed'] is False
        for payload in proof['payloads']:
            assert payload['matches'] is True and payload['subjectIntegrity'] is True and r['source']['H'] in payload['sourceCommits'] and payload['invocation']=='https://github.com/ubugeeei-prod/vize/actions/runs/38037918678/attempts/2'
    counts.append({'name':p['name'],'files':len(declared)})
assert sum(p['files'] for p in counts)==202
old=json.loads(pathlib.Path('<LOCAL_TMP>/vize-lsp440-20261010-5998a437/receipts/public-authority.json').read_bytes())
assert r['collectorAuthority']==old['collectorAuthority'] and r['collectorAuthority']['sha256']=='a26411442a3fde2590d969160fd83b97685e9019d2de4decb0c103a376f10786'
for f in r['collectorAuthority']['files']: read(SOURCE/f['path'],f['sha256'])
launch=json.loads(read(BASE/'receipts/launch.json'))
with tarfile.open(launch['collectorSnapshotPath']) as tar:
    members=tar.getmembers();assert len(members)==8
    assert set(m.name for m in members)==set(f['path'] for f in r['collectorAuthority']['files'])
    for member in members:
        assert member.isfile(); assert tar.extractfile(member).read()==(SOURCE/member.name).read_bytes()
read(launch['collectorSnapshotPath'],launch['collectorSnapshotArchiveSha256'])
assert launch['sourceOverrides']=={k:'' for k in ['NODE_OPTIONS','VIZE_PREFER_WORKSPACE_BINDING','NAPI_RS_NATIVE_LIBRARY_PATH','NAPI_RS_FORCE_WASI','VIZE_ALLOW_NATIVE_VERSION_MISMATCH','CORSA_PATH','CORSA_EXECUTABLE','TSGO_PATH','TSGO_EXECUTABLE','VIZE_PUBLIC_NATIVE_CUSTODY','VIZE_OXLINT_NATIVE_CUSTODY']} and launch['npmExitCode']==0
assert r['sourceOverrides']=={k:'' for k in r['sourceOverrides']} and set(r['sourceOverrides']).issubset(launch['sourceOverrides'])
seal=json.loads(read(BASE/'receipts/terminal-publication-seal.json',launch['terminalSealSha256']))
assert seal['source']['H']==r['source']['H'] and seal['source']['C']==r['source']['C'] and seal['source']['releaseRun']==int(r['source']['R']) and seal['source']['sourcePr']==8473
run=json.loads(read(BASE/'receipts/terminal-release-run.json',launch['terminalRunSha256']))
assert run['status']=='completed' and run['conclusion']=='success' and run['head_sha']==r['source']['H'] and run['run_attempt']==2
read(r['node']['path'],r['node']['sha256']);read(r['cli']['binPath'],r['cli']['binSha256']);read(r['cli']['distCliPath'],r['cli']['distCliSha256']);read(r['native']['path'],r['native']['sha256']);read(r['bundledCorsa']['path'],r['bundledCorsa']['sha256'])
assert r['native']['actualLoadedPath']==r['native']['path'] and r['native']['successfulReturnObserved'] is True
journal=read(r['native']['journalPath'],r['native']['journalSha256']);assert journal[-1:]==b'\n'
events=[json.loads(line) for line in journal.splitlines()]
assert [e['event'] for e in events]==['initialized','attempt','returned']
assert events[0]['argv']==[r['node']['path'],r['cli']['binPath'],'--version'] and events[0]['installRoot']==r['installRoot']
for e in events:
    assert e['pid']==events[0]['pid'] and e['sha256']==r['native']['sha256'] and e['schema']=='vize-public-native-custody-event-v1'
for e in events[1:]:
    assert e['actualPath']==r['native']['path'] and e['expectedNative'] is True and e['corsaPath']==r['bundledCorsa']['path']
assert r['cli']['versionStdout']=='vize 0.441.0\n' and r['cli']['versionStderr']=='' and r['cli']['versionExitCode']==0
packet={'schema':'vize-public-install-independent-custody-review-v1','source':r['source'],'publicReceiptPath':str(receipt),'publicReceiptSha256':sha(receipt.read_bytes()),'packageCounts':counts,'all202PayloadFilesCanonicalBytesEqual':True,'lockSha256':r['packageLockSha256'],'manifestSha256':r['payloadManifestSha256'],'collectorSha256':r['collectorAuthority']['sha256'],'nativeOriginalReturnPid':events[0]['pid'],'nativeSha256':r['native']['sha256'],'terminalPublicationBound':True,'runtimeProviders':0,'cryptoSignatureVerificationPerformed':False,'success':True}
output=BASE/'receipts/independent-custody-review.json';output.write_text(json.dumps(packet,indent=2)+'\n')
print(json.dumps({'path':str(output),'sha256':sha(output.read_bytes()),'all202':True,'success':True}))
