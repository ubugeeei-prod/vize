import hashlib,json,os,pathlib,subprocess,sys
keys=['NODE_OPTIONS','VIZE_PREFER_WORKSPACE_BINDING','NAPI_RS_NATIVE_LIBRARY_PATH','NAPI_RS_FORCE_WASI','VIZE_ALLOW_NATIVE_VERSION_MISMATCH','CORSA_PATH','CORSA_EXECUTABLE','TSGO_PATH','TSGO_EXECUTABLE','VIZE_PUBLIC_NATIVE_CUSTODY','VIZE_OXLINT_NATIVE_CUSTODY']
assert all(not os.environ.get(k) for k in keys),'initial source/runtime override is nonempty'
def sha(p):return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
node='<USER_HOME>/.vite-plus/js_runtime/node/24.14.0/bin/node'
script='<LOCAL_TMP>/vize-jsx8419-installed-green-20261010.mjs'
helper='<LOCAL_TMP>/vize-jsx8419-red-archive-custody-20261010.mjs'
assert sha(node)=='20a18709f0154d668f1bd6f6ea8c2a7ae001447b4b2c339732f22e57a8767a55'
assert sha(script)=='e3e9eebaa48615b807d43435517d1557d6587ca21e6e2c50f423d92c877f2adc'
assert sha(helper)=='d800640bbf60c53f07226bb3ee93c4796dadbd57647fb21fed151d545a3a21ef'
receipt='<LOCAL_TMP>/vize-lsp441-20261010-bb83dd98/receipts/public-authority.json'
assert sha(receipt)=='d9a29f1029bbd386b722d7ddbcc5fe876649050fdf78c19bd913b193eb29557b'
argv=[node,script,'--authority',receipt,'--authority-sha256',sha(receipt),'--output','<LOCAL_TMP>/vize-jsx8419-installed-green-20261010-v0441']
record={'schema':'vize-installed-jsx-slot-launch-v1','initialOverrides':{k:'' for k in keys},'nodeSha256':sha(node),'runnerSha256':sha(script),'redVerifierSha256':sha(helper),'argv':argv,'receiptSha256':sha(receipt)}
base=pathlib.Path('<LOCAL_TMP>/vize-lsp441-20261010-bb83dd98/receipts')
with (base/'jsx8419-launch.json').open('x') as out:json.dump(record,out,indent=2);out.write('\n')
with (base/'jsx8419-green.stdout').open('xb') as out,(base/'jsx8419-green.stderr').open('xb') as err:
    r=subprocess.run(argv,stdout=out,stderr=err)
print(json.dumps({'exitCode':r.returncode,'output':argv[-1],'stdout':str(base/'jsx8419-green.stdout'),'stderr':str(base/'jsx8419-green.stderr')}))
sys.exit(r.returncode)
