// 日本語 😀
import Child from './Child.vue';
const view = <Child>{{ default: (props: { value: number } = { value: 1 }) => props.value.toFixed() }}</Child>;
