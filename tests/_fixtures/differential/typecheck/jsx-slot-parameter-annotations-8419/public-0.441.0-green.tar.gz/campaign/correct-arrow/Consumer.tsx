// 日本語 😀
import Child from './Child.vue';
const view = <Child>{{ default: (props: { value: number }) => props.value.toFixed() }}</Child>;
