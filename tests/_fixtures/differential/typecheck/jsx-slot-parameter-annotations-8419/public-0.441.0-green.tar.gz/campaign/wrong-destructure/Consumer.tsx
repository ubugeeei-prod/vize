// 日本語 😀
import Child from './Child.vue';
const view = <Child>{{ default: ({ value }: { value: string }) => value }}</Child>;
