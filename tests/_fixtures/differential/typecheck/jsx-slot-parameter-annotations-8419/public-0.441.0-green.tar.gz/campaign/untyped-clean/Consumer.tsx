// 日本語 😀
import Child from './Child.vue';
const view = <Child>{{ default: props => props.value.toFixed() }}</Child>;
