import assert from 'node:assert/strict';
import { mkdtemp, mkdir, writeFile, rm } from 'node:fs/promises';
import path from 'node:path';
import os from 'node:os';
import { fileURLToPath } from 'node:url';
import { createServer } from 'vite';
import { chromium } from 'playwright';
import vize from '../../vite/src/index.ts';
import { musea } from '../src/plugin/index.ts';
import { processMuseaArtFile } from '../src/plugin/art-processing.ts';
import { parseScriptSetupForArt } from '../src/art-module.ts';
import { resolveArtComponent } from '../src/art-component.ts';
import { loadNative } from '../src/native-loader.ts';
const root = await mkdtemp(path.join(os.tmpdir(),'musea-native-title-'));
const out = process.env.MUSEA_TITLE_PROOF!;
assert.ok(out);
await mkdir(path.join(root,'src'),{recursive:true});
const source = `<script setup lang="ts">\nimport {default as AliasButton} from './base-button.vue';\ndefineArt(AliasButton, {title: 'Props / Probe'});\n</script>\n<art><variant name="Default" default><Self label="Seed" /></variant></art>`;
const componentSource = `<script setup lang="ts">\nimport {toRaw} from 'vue';\nconst props=defineProps<{label?:string}>();\n</script>\n<template><output>{{JSON.stringify(toRaw(props))}}</output></template>`;
const artPath=path.join(root,'src/probe.art.vue');
await writeFile(artPath,source);
await writeFile(path.join(root,'src/base-button.vue'),componentSource);
await writeFile(path.join(root,'index.html'),'<!doctype html><html><body></body></html>');
const nativeArt=await processMuseaArtFile(artPath,{root,command:'build'});
assert.ok(nativeArt);
const resolved=resolveArtComponent(nativeArt,artPath,parseScriptSetupForArt(nativeArt.scriptSetupContent!),{root,scanRoots:[root]});
const server=await createServer({root,configFile:false,resolve:{alias:{vue:fileURLToPath(import.meta.resolve('vue/dist/vue.runtime.esm-bundler.js'))}},plugins:[vize(),musea({include:['src/**/*.vue'],inlineArt:true})],server:{host:'127.0.0.1',port:0}});
const browser=await chromium.launch();
const errors:string[]=[];
const receipt:Record<string,unknown>={boundary:'Published 0.440 native binary with current-source UI; no current Rust or release acceptance credit',source,componentSource,nativeArt,resolved,errors};
try {
 await server.listen();const address=server.httpServer!.address();assert.ok(address&&typeof address!=='string');
 const context=await browser.newContext({permissions:['clipboard-read','clipboard-write']});
 const page=await context.newPage();page.on('pageerror',error=>errors.push(String(error)));
 await page.goto(`http://127.0.0.1:${address.port}/__musea__/`);
 await page.locator('.art-item').first().click();
 const response=page.waitForResponse(r=>new URL(r.url()).pathname.endsWith('/palette'));
 await page.locator('.tab-btn').filter({hasText:'Props'}).click();
 receipt.palette=await (await response).json();
 await page.getByRole('textbox',{name:'label',exact:true}).fill('Native title probe');
 await page.frameLocator('.props-preview iframe').locator('output').filter({hasText:'Native title probe'}).waitFor();
 receipt.rendered=await page.frameLocator('.props-preview iframe').locator('output').textContent();
 receipt.currentValues=JSON.parse((await page.locator('.props-json-code code').textContent())!);
 await page.locator('.props-copy-btn').click();receipt.copied=await page.evaluate(()=>navigator.clipboard.readText());
 const copiedPath=path.join(root,'src/Copied.vue');
 await writeFile(copiedPath,receipt.copied as string);
 receipt.nativeCopiedCompilation=loadNative().compileSfc(receipt.copied as string,{filename:copiedPath});
 await writeFile(path.join(root,'copied-entry.js'),`
 try {const {createApp}=await import('vue');const {default:Copied}=await import('/src/Copied.vue');createApp(Copied).mount('#app');window.__copyRuntime={status:'mounted',html:document.querySelector('#app').innerHTML};}
 catch(error){window.__copyRuntime={status:'failed',error:String(error)};}
 `);
 await writeFile(path.join(root,'copied.html'),`<!doctype html><html><body><main id="app"></main><script type="module" src="/copied-entry.js"></script></body></html>`);
 const copiedPage=await context.newPage();const copiedErrors:string[]=[];
 copiedPage.on('pageerror',error=>copiedErrors.push(String(error)));
 await copiedPage.goto(`http://127.0.0.1:${address.port}/copied.html`);
 await copiedPage.waitForFunction(()=>Reflect.has(window,'__copyRuntime'));
 receipt.copiedRuntime=await copiedPage.evaluate(()=>({runtime:Reflect.get(window,'__copyRuntime'),output:document.querySelector('output')?.textContent||null,html:document.documentElement.outerHTML}));
 receipt.copiedPageErrors=copiedErrors;
 await copiedPage.screenshot({path:path.join(out,'copied-before.png'),fullPage:true});
 await page.screenshot({path:path.join(out,'before.png'),fullPage:true});
 receipt.documents=await Promise.all(page.frames().map(async frame=>({url:frame.url(),html:await frame.content()})));
 await writeFile(path.join(out,'before.json'),JSON.stringify(receipt,null,2)+'\n');
 assert.equal(JSON.parse(receipt.rendered as string).label,'Native title probe');
 assert.ok((receipt.copied as string).includes(`<${resolved.componentTagName} `),'Clipboard must use actual resolved alias');
} catch(error) {
 receipt.failure=error instanceof Error?{name:error.name,message:error.message,stack:error.stack}:String(error);
 await writeFile(path.join(out,'before.json'),JSON.stringify(receipt,null,2)+'\n');throw error;
} finally {await browser.close();await server.close();await rm(root,{recursive:true,force:true});}
