import { createRequire } from 'node:module';
const require = createRequire(import.meta.url);
require('../../../native/index.js');
// NAPI-RS also names the unrelated Vite/Rolldown binding override this way.
// Load only the official Vize loader with its supported explicit binary path,
// then let other packages resolve their own unmodified bindings normally.
delete process.env.NAPI_RS_NATIVE_LIBRARY_PATH;
await import('./native-title-probe.ts');
