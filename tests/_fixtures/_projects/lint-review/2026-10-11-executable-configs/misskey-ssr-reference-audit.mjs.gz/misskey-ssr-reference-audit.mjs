import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import { createRequire } from 'node:module';
const root='/Users/ubugeeei/Source/github.com/ubugeeei-prod/vize';
const evidence='/tmp/vize-app-e2e-lint-diagnosis-20261011';
const sourceRoot='/Users/ubugeeei/Source/github.com/ubugeeei-prod/vize.fix-app-e2e-lint-fixture-dependencies-20261011/tests/_fixtures/_git/misskey/packages/frontend';
const requireProvider=createRequire(path.join(root,'tools/benchmarks/scripts/package.json'));
const parser=requireProvider('vue-eslint-parser');
const tsParser=requireProvider('@typescript-eslint/parser');
const delta=JSON.parse(fs.readFileSync(path.join(evidence,'newly-executable-whole-packet-deltas.json'),'utf8')).find(x=>x.project==='misskey');
const facts=[];
for(const file of new Set(delta.added.filter(x=>x.message.ruleId==='ssr/no-browser-globals-in-ssr').map(x=>x.file))){
 const source=fs.readFileSync(path.join(sourceRoot,file),'utf8');
 const parsed=parser.parseForESLint(source,{parser:tsParser,ecmaVersion:'latest',sourceType:'module',range:true,loc:true,filePath:file});
 const refs=new Map(parsed.scopeManager.scopes.flatMap(scope=>scope.references.map(ref=>[ref.identifier,ref])));
 const parents=new Map();const ids=[];const calls=[];
 function collect(node,parent){
  if(!node||typeof node!=='object'||typeof node.type!=='string')return;
  if(parent)parents.set(node,parent);
  if(node.type==='Identifier')ids.push(node);
  if(node.type==='CallExpression')calls.push(node);
  for(const [key,value] of Object.entries(node)){
   if(['parent','tokens','comments','templateBody'].includes(key))continue;
   if(Array.isArray(value))for(const child of value)collect(child,node);else collect(value,node);
  }
 }
 collect(parsed.ast);
 const functionNodes=new Set(['FunctionDeclaration','FunctionExpression','ArrowFunctionExpression']);
 function enclosingFunction(node){while((node=parents.get(node)))if(functionNodes.has(node.type))return node;return null;}
 for(const change of delta.added.filter(x=>x.file===file&&x.message.ruleId==='ssr/no-browser-globals-in-ssr')){
  const message=change.message;
  const name=message.message.split("'")[1];
  const id=ids.find(node=>node.name===name&&node.loc.start.line===message.line&&node.loc.start.column+1===message.column);
  assert.ok(id,`${file}:${message.line}: exact runtime identifier AST`);
  const ref=refs.get(id);
  assert.ok(ref,`${file}:${message.line}: semantic reference`);
  const isValue=typeof ref.isValueReference==='function'?ref.isValueReference():ref.isValueReference;
  assert.equal(isValue,true,`${file}:${message.line}: value reference`);
  assert.equal(ref.resolved,null,`${file}:${message.line}: unresolved actual global`);
  const fn=enclosingFunction(id);
  let executionWitness={kind:'script-setup-top-level'};
  if(fn){
   const binding=fn.id?.name??(parents.get(fn)?.type==='VariableDeclarator'?parents.get(fn).id?.name:null);
   assert.ok(binding,`${file}:${message.line}: identify local function binding`);
   const directCalls=calls.filter(call=>call.callee.type==='Identifier'&&call.callee.name===binding&&!enclosingFunction(call));
   assert.ok(directCalls.length,`${file}:${message.line}: direct setup invocation`);
   executionWitness={kind:'same-file-function-directly-called-by-setup',function:binding,functionLine:fn.loc.start.line,topLevelCalls:directCalls.map(call=>({line:call.loc.start.line,column:call.loc.start.column+1,source:source.slice(call.range[0],call.range[1])}))};
  }
  facts.push({wholePacket:change,identifierRange:id.range,identifierSource:source.slice(...id.range),semanticValueReference:true,unresolvedGlobal:true,executionWitness});
 }
}
assert.equal(facts.length,65);
fs.writeFileSync(path.join(evidence,'misskey-65-ssr-runtime-reference-provenance.json'),JSON.stringify({scope:'Source and semantic reference witness, not complete SSR execution, reachability, external guard or Options API proof',facts},null,2)+'\n');
console.log(JSON.stringify({messages:facts.length,directLocalFunctions:facts.filter(x=>x.executionWitness.kind!=='script-setup-top-level').map(x=>({file:x.wholePacket.file,line:x.wholePacket.message.line,...x.executionWitness}))},null,2));
