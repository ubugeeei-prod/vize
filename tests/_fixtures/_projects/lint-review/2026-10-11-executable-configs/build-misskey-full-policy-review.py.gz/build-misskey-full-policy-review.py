import collections
import hashlib
import json
import os
import re
import subprocess
from pathlib import Path

evidence = Path('/tmp/vize-app-e2e-lint-diagnosis-20261011')
repo = Path('/Users/ubugeeei/Source/github.com/ubugeeei-prod/vize')
source_root = Path('/Users/ubugeeei/Source/github.com/ubugeeei-prod/vize.fix-app-e2e-lint-fixture-dependencies-20261011/tests/_fixtures/_git/misskey/packages/frontend')
producer = '2b367c41b569e3d4a1bc78d03f3d9f4c8698f13c'
delta = next(item for item in json.loads((evidence / 'newly-executable-whole-packet-deltas.json').read_text()) if item['project'] == 'misskey')
provenance = json.loads((evidence / 'misskey-all-583-file-packet-source-provenance.json').read_text())
sources = {item['file']: item for item in provenance['files']}
packets = {item['file']: item for item in delta['whole_changed_packets']}
sinks = {item['removed_index']: item for item in json.loads((evidence / 'misskey-unsafe-url-source-sinks.json').read_text())}
ssr = json.loads((evidence / 'misskey-65-ssr-runtime-reference-provenance.json').read_text())['facts']
official52 = json.loads((evidence / 'misskey-official-52-capture.json').read_text())
official = {item['caseId'] + '.vue': item for item in official52['captures']}

policy = {
    'a11y/img-alt': (['1d7ff3b2b05e1e93a68d37c291d1683e653df5ba'], ['crates/vize_patina/src/rule.rs', 'crates/vize_patina/src/rules/a11y.rs', 'crates/vize_patina/src/preset/tests.rs']),
    'vue/no-unsafe-url': (['85cc05b89b5b16b8d302cd44ca124bab2d17c9ea'], ['crates/vize_patina/src/rules/vue/no_unsafe_url.rs', 'crates/vize_patina/src/rules/vue/no_unsafe_url/tests.rs']),
    'vue/no-unused-components': (['00bceccf4baa4fe46eb395673677fc01ef1be197'], ['crates/vize_patina/src/rules/vue/no_unused_components.rs']),
    'a11y/interactive-supports-focus': (['bfb7c96b81041903f4feb3164433fde717fc45b9'], ['crates/vize_patina/src/rules/a11y/markup_helpers.rs', 'crates/vize_patina/src/rules/a11y/interactive_supports_focus.rs']),
    'vue/attribute-hyphenation': (['b731cd547528cdde8cbb1b8fb68d0470afa16ac7'], ['crates/vize_patina/src/rules/vue/attribute_hyphenation.rs', 'crates/vize_patina/src/rules/vue/attribute_hyphenation/tests.rs']),
    'ssr/no-browser-globals-in-ssr': (['bfb7c96b81041903f4feb3164433fde717fc45b9', 'c30f1a02da763e0086c489b8e17b9aa558187cff'], ['crates/vize_patina/src/rules/ssr/no_browser_globals_in_ssr/template_identifiers.rs', 'crates/vize_patina/src/rules/ssr/no_browser_globals_in_ssr/type_ranges.rs', 'crates/vize_patina/src/rules/ssr/no_browser_globals_in_ssr/script_reads.rs', 'crates/vize_patina/src/rules/ssr/no_browser_globals_in_ssr/script_symbols.rs']),
    'vue/component-definition-name-casing': (['341fd1ba1d28391ed9973f2675727e27c3d3c731'], ['crates/vize_patina/src/component_name.rs', 'crates/vize_patina/src/rules/vue/component_definition_name_casing.rs', 'crates/vize_patina/src/native/template/component_name.rs']),
    'script/no-required-prop-with-default': (['fd20178fa311bcd5d78d1f0241a671d7d1753185'], ['crates/vize_patina/src/linter/script_rules/prefilter.rs', 'crates/vize_patina/src/rules/script/props_emits/no_required_prop_with_default/typed.rs']),
    'vue/no-unused-properties': (['094739fbcda25f3b4c41d03c72f04a6a1242aa2d'], ['crates/vize_patina/src/rules/vue/no_unused_properties.rs', 'crates/vize_patina/src/rules/vue/no_unused_properties/usage.rs']),
}
producer_sources = {}
for commits, paths in policy.values():
    for commit in commits:
        subprocess.run(['git', 'merge-base', '--is-ancestor', commit, producer], cwd=repo, check=True)
    for path in paths:
        if path in producer_sources:
            continue
        content = subprocess.check_output(['git', 'show', producer + ':' + path], cwd=repo)
        producer_sources[path] = {'producer': producer, 'gitBlob': subprocess.check_output(['git', 'rev-parse', producer + ':' + path], cwd=repo, text=True).strip(), 'sha256': hashlib.sha256(content).hexdigest(), 'source': content.decode()}
(evidence / 'misskey-reviewed-producer-sources.json').write_text(json.dumps(producer_sources, indent=2) + '\n')

entries = []
for side in ['removed', 'added']:
    for index, packet in enumerate(delta[side]):
        file = packet['file']
        message = packet['message']
        rule = message['ruleId']
        assert message['severity'] == (2 if rule == 'script/no-required-prop-with-default' else 1)
        assert set(message) == {'column', 'endColumn', 'endLine', 'help', 'line', 'message', 'ruleDocsPath', 'ruleId', 'severity'}
        lines = (source_root / file).read_text().splitlines()
        n = message['line']
        context = [{'line': i + 1, 'source': lines[i]} for i in range(max(0, n - 5), min(len(lines), max(n + 5, message['endLine'] + 3)))]
        entry = {'kind': side, 'index': index, 'whole_packet': packet, 'source_provenance': sources[file], 'source_context': context, 'owning_policy_commits': policy[rule][0], 'current_producer_sources': [{k: v for k, v in producer_sources[path].items() if k != 'source'} | {'path': path} for path in policy[rule][1]], 'status': 'justified-under-current-bounded-policy'}
        if rule == 'vue/no-unsafe-url':
            assert side == 'removed'
            witness = sinks[index]
            assert not witness['active_dom_sink']
            entry['sink_witness'] = witness
            entry['review'] = 'Original sink is image/media or an unresolved component property. It is outside the committed active physical DOM sink predicate; no active DOM sink was removed. Component forwarding and runtime sanitization are not proved or assumed.'
        elif rule == 'a11y/img-alt':
            assert side == 'removed'
            counterpart = [item for item in packets[file]['actual']['messages'] if item['ruleId'] == 'a11y/alt-text' and all(item.get(key) == message.get(key) for key in ['line', 'column', 'endLine', 'endColumn', 'severity'])]
            assert len(counterpart) == 1
            entry['retained_whole_counterpart'] = counterpart[0]
            entry['review'] = 'The preset duplicate alias was removed. The same physical original element retains the full owning a11y/alt-text warning at the same location/severity. Explicit img-alt opt-in is retained in producer tests.'
        elif rule == 'vue/no-unused-components':
            opposite = 'added' if side == 'removed' else 'removed'
            pairs = [item for item in delta[opposite] if item['file'] == file and all(item['message'].get(key) == value for key, value in message.items() if key not in ['line', 'column', 'endLine', 'endColumn'])]
            assert len(pairs) == 1
            added = packet if side == 'added' else pairs[0]
            m = added['message']
            name = re.search("Component '([^']+)'", m['message']).group(1)
            assert lines[m['line'] - 1][m['column'] - 1:m['endColumn'] - 1] == name
            assert re.match(r'^import ' + re.escape(name) + r' from ', lines[m['line'] - 1])
            entry['paired_whole_packet'] = pairs[0]
            entry['original_import_declaration'] = {'line': m['line'], 'source': lines[m['line'] - 1]}
            entry['review'] = 'This is one half of an exact same-file diagnostic pair: all fields except physical coordinates are equal. Actual coordinates select the exact authored script import binding; the old template offset is retired without deleting the finding.'
        elif rule == 'a11y/interactive-supports-focus':
            assert side == 'removed' and file == 'src/components/MkMenu.vue' and n in [34, 42]
            assert 'role="menuitem"' in lines[n - 1] and 'tabindex="-1"' in lines[n - 1]
            entry['review'] = 'Both authored menuitem divs have static tabindex=-1. The committed helper accepts >= -1 as programmatically focusable and the owning change includes exact SFC/template -1 positive and -2 negative tests. This does not claim sequential keyboard navigation or whole-menu accessibility.'
        elif rule == 'vue/attribute-hyphenation':
            assert side == 'removed' and file == 'src/pages/admin/job-queue.vue' and n in [27, 48]
            assert ':dataSet=' in lines[n - 1]
            entry['review'] = 'The original XChart prop is :dataSet. The deliberate committed camel aria/data component-prop exemption matches data followed by uppercase S. The official ESLint always rule still reports dataSet; no full official attribute-rule parity is claimed.'
            official_matches = [m for p in official[file]['packets'] for m in p['messages'] if m['ruleId'] == 'vue/attribute-hyphenation' and m['line'] == n]
            assert any('dataSet' in m['message'] for m in official_matches)
            entry['official_whole_packets_on_same_source_line'] = official_matches
        elif rule == 'ssr/no-browser-globals-in-ssr':
            if side == 'removed':
                assert file in ['src/components/MkTabs.vue', 'src/components/global/MkPageHeader.tabs.vue'] and n == 11
                assert '(el as HTMLElement)' in lines[n - 1]
                entry['review'] = 'Original ref callback occurrence is the TypeScript as HTMLElement assertion, not a browser constructor read. The committed template type-range suppression retires it; no runtime event/body execution claim is made.'
            else:
                matches = [item for item in ssr if item['wholePacket'] == packet]
                assert len(matches) == 1
                entry['runtime_reference_witness'] = matches[0]
                entry['review'] = 'Exact original span is an unresolved semantic value reference. Source witness shows setup top-level execution or a same-file function directly invoked from setup. This matches the committed bounded SSR script rule, with no external interprocedural, Options API, full reachability, or consumer SSR guarantee.'
        elif rule == 'vue/component-definition-name-casing':
            assert side == 'added'
            stem = Path(file).name[:-4]
            assert '.' in stem and '/pages/' not in file
            assert not re.fullmatch(r'[A-Z][A-Za-z0-9]*', stem)
            assert not re.fullmatch(r'[a-z][a-z0-9]*(?:-[a-z0-9]+)*', stem)
            entry['physical_filename_stem'] = stem
            entry['review'] = 'Original physical component stem contains a dot and is neither the committed strict ASCII-alphanumeric PascalCase nor kebab-case predicate. Explicit dotted-name negative fixture is retained. This physical filename policy differs from the official component definition name rule; no alias/parity or added exemption is assumed.'
        elif rule == 'script/no-required-prop-with-default':
            assert side == 'added'
            name = message['message'].split("'")[1]
            declarations = [{'line': i + 1, 'source': line} for i, line in enumerate(lines) if re.match(r'^\s*' + re.escape(name) + ':', line)]
            assert len(declarations) == 2
            matches = [m for p in official[file]['packets'] for m in p['messages'] if m['ruleId'] == 'vue/no-required-prop-with-default' and '"' + name + '"' in m['message']]
            assert len(matches) == 1 and matches[0]['severity'] == 2
            assert lines[n - 1][message['column'] - 1:message['endColumn'] - 1] == name
            entry['required_type_and_default_declarations'] = declarations
            entry['official_whole_required_default_message'] = matches[0]
            entry['official_full_capture'] = {'path': 'misskey-official-52-capture.json', 'caseId': file[:-4], 'original51Unchanged': True, 'explicitAdditionalRule': 'vue/no-required-prop-with-default', 'severity': 'error'}
            entry['review'] = 'Required inline typed macro member lacks ? and the original withDefaults object declares a default for the same name. Actual pinned official Vue rule confirms identical prop identity and severity 2; all official message, suggestion, fix-range fields are retained. Native anchors the default key while official anchors the required type member. Prefilter fix #8565 exposes existing typed implementation; no removal or severity waiver is justified.'
        elif rule == 'vue/no-unused-properties':
            assert side == 'added' and file == 'src/components/MkPushNotificationAllowButton.vue' and n == 60
            occurrences = [{'line': i + 1, 'source': line} for i, line in enumerate(lines) if re.search(r'\bto\b', line)]
            assert [item['line'] for item in occurrences] == [60, 72, 151]
            entry['all_original_standalone_name_occurrences'] = occurrences
            entry['review'] = 'Bare defineProps declares optional to but no template expression or script reference reads it. The only other standalone to tokens are comments at lines 72 and 151. The exact #6700 AST-reference correction excludes comments/import strings previously treated as usage. Severity remains warning and actual declaration span is retained.'
        else:
            raise AssertionError(rule)
        entries.append(entry)
assert len(entries) == 351
report = {
    'schema': 'vize.misskey.whole-packet-source-policy-review',
    'producer': producer,
    'sourceRevision': provenance['originalRevision'],
    'run': 38115805398,
    'job': 114400465871,
    'artifact': 11692924427,
    'artifactZipSha256': '400533862993ac7e3d43c520bc511008a27d46532eba5134d83585cbd7b7cf4f',
    'jobRawLogSha256': '42be29366a01c3a8caedd9a2bd655d3687867477b255f2cacfec5b941b84f18e',
    'completeOriginalFilePackets': 583,
    'identicalOriginalFilePackets': 414,
    'changedOriginalFilePackets': 169,
    'removedMessages': 231,
    'addedMessages': 120,
    'reviewedWholeMessages': len(entries),
    'unjustifiedChangedMessagesFound': [],
    'originalAll4751BlobAndNestedGitlinkReceipt': '.vize/artifacts/lint-fixtures/misskey.json in original artifact ZIP',
    'fullOriginalSourcePacketProvenance': 'misskey-all-583-file-packet-source-provenance.json',
    'providerCaptures': [
        {'path': 'misskey-official-all51-capture.json', 'sha256': hashlib.sha256((evidence / 'misskey-official-all51-capture.json').read_bytes()).hexdigest(), 'files': 169, 'rules': 51, 'fatalErrorPackets': 0, 'retainedUnusedDisableWarnings': 6, 'purpose': 'Unchanged complete owned projection, not a claim of full incremental-preset equality'},
        {'path': 'misskey-official-52-capture.json', 'sha256': hashlib.sha256((evidence / 'misskey-official-52-capture.json').read_bytes()).hexdigest(), 'files': 169, 'rules': 52, 'fatalErrorPackets': 0, 'retainedUnusedDisableWarnings': 6, 'purpose': 'Original 51 unchanged plus explicit official required-prop-default rule for the five new typed-default witnesses'},
    ],
    'officialTypedRuleDocumentation': 'https://eslint.vuejs.org/rules/no-required-prop-with-default.html',
    'limits': ['No whole official/native packet equality is claimed for different authored configurations, schemas or known physical filename/camel data-prop policy differences.', 'SSR witness is bounded authored lexical/direct-call analysis, not complete application SSR acceptance.', 'This audit does not make the failing full App E2E run green and does not authorize omission of any original case, field, manager, frozen graph or gate.', 'No production, expectation, upstream, local branch or remote state was modified by this read-only audit.'],
    'entries': entries,
}
(evidence / 'misskey-new-whole-policy-review.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({k: v for k, v in report.items() if k not in ['entries', 'limits', 'providerCaptures']}, indent=2))
