import json,pathlib,subprocess,hashlib,re,collections
p=pathlib.Path('/tmp/vize-app-e2e-lint-diagnosis-20261011'); wt=pathlib.Path('/Users/ubugeeei/Source/github.com/ubugeeei-prod/vize.fix-app-e2e-lint-fixture-dependencies-20261011'); root=wt/'tests/_fixtures/_git/npmx.dev'; head='2b367c41b569e3d4a1bc78d03f3d9f4c8698f13c'
x=next(x for x in json.loads((p/'newly-executable-whole-packet-deltas.json').read_text()) if x['project']=='npmx.dev'); oracle=json.loads((p/'official-51-npmx-new-capture.json').read_text()); contexts=json.loads((p/'npmx-new-message-contexts.json').read_text())
def git(args,cwd=wt): return subprocess.check_output(['git',*args],cwd=cwd)
def sha(b): return hashlib.sha256(b).hexdigest()
originalpin='c9e8be91e61eeeae956e2068722caa09e293cc68'; assert git(['rev-parse','HEAD'],root).decode().strip()==originalpin
previous=git(['log','-1','--format=%H','--',x['snapshot']]).decode().strip(); assert git(['rev-parse',previous+':tests/_fixtures/_git/npmx.dev']).decode().strip()==originalpin
actual=p/'8589-corrected-lint-11692924427/target/app-e2e-logs/full-lint-all.log'
rows=[]; lookup={r['file']:r for r in x['whole_changed_packets']}
policies={
'vue/no-unsafe-url':('85cc05b89b5b16b8d302cd44ca124bab2d17c9ea','crates/vize_patina/src/rules/vue/no_unsafe_url.rs'),
'a11y/img-alt':('1d7ff3b2b05e1e93a68d37c291d1683e653df5ba','crates/vize_patina/src/rules/a11y.rs'),
'a11y/anchor-has-content':('1d7ff3b2b05e1e93a68d37c291d1683e653df5ba','crates/vize_patina/src/rules/a11y/anchor_has_content.rs'),
'vue/attribute-hyphenation':('b731cd547528cdde8cbb1b8fb68d0470afa16ac7','crates/vize_patina/src/rules/vue/attribute_hyphenation.rs'),
'a11y/role-has-required-aria-props':('bfb7c96b81041903f4feb3164433fde717fc45b9','crates/vize_patina/src/rules/a11y/role_has_required_aria_props.rs'),
'a11y/no-aria-hidden-on-focusable':('bfb7c96b81041903f4feb3164433fde717fc45b9','crates/vize_patina/src/rules/a11y/no_aria_hidden_on_focusable.rs'),
'vue/component-definition-name-casing':('341fd1ba1d28391ed9973f2675727e27c3d3c731','crates/vize_patina/src/rules/vue/component_definition_name_casing.rs'),
'ssr/no-browser-globals-in-ssr':('c30f1a02da763e0086c489b8e17b9aa558187cff','crates/vize_patina/src/rules/ssr/no_browser_globals_in_ssr/script_reads.rs')}
for kind in ['removed','added']:
 for whole in x[kind]:
  file=whole['file']; m=whole['message']; rule=m['ruleId']; blob=git(['show',originalpin+':'+file],root); assert (root/file).read_bytes()==blob; source=blob.decode(); lines=source.splitlines(); region='\n'.join(lines[max(m['line']-3,0):min(m['endLine']+2,len(lines))]); commit,producer=policies[rule]
  cap=next(c for c in oracle['captures'] if c['caseId']=='npmx.dev/'+file[:-4]); assert cap['sourceSha256']==sha(blob)
  row={'snapshot':x['snapshot'],'kind':kind,'whole_packet':whole,'producer_head':head,'producer_path':producer,'producer_blob_oid':git(['rev-parse',head+':'+producer]).decode().strip(),'owning_policy_commit':commit,'source_pin':originalpin,'source_blob_oid':git(['rev-parse',originalpin+':'+file],root).decode().strip(),'source_sha256':sha(blob),'source_context':region,'official_capture_case':cap['caseId'],'status':'reviewed_existing_policy'}
  if rule=='vue/no-unsafe-url':
   assert kind=='removed'; assert ':src' in region or ':href' in region
   if '<use' in region:
    assert '/file-tree-sprite.svg#' in region; row['review']='Original SVG use href has an authored fixed same-origin sprite path and fragment. Current native active-sink predicate excludes use, and the expression cannot introduce a javascript protocol before that fixed prefix. No active-link warning is waived.'
   elif any(tag in region for tag in ['<img','<video','<source']): row['review']='Original image/media resource binding is outside the authenticated current active-navigation/executable sink predicate. Complete original dynamic expression and message fields retained.'
   else: row['review']='Original custom component prop has no proven native executable URL destination; current native predicate explicitly requires native Element classification. No prop forwarding assumption made.'
  elif rule=='a11y/img-alt':
   pair=lookup[file]; retained=[z for z in pair['actual']['messages'] if z['ruleId']=='a11y/alt-text' and z['line']==m['line'] and z['column']==m['column']]; assert len(retained)==1 and retained[0] in pair['expected']['messages']; row['retained_alias_packet']=retained[0]; row['review']='Only duplicate default img-alt alias removed; the identical whole original a11y/alt-text packet at this original image remains in both before and after.'
  elif rule=='a11y/anchor-has-content':
   assert '<a' in region and ':alt=' in source and "Embedded image" in source; row['source_context']=source.splitlines()[148:170]; row['review']='Original anchor contains an image with nonempty bound alt fallback. Existing anchor content fix recognizes bound alt; no source or accessibility field changed.'
  elif rule=='vue/attribute-hyphenation':
   assert re.search(r'aria[A-Z]',region); official=[z for pkt in cap['packets'] for z in pkt['messages'] if z['ruleId']==rule and z['line']==m['line']]; assert len(official)==1; row['official_divergence_packet']=official[0]; row['review']='Authored camelCase aria prop is deliberately exempt under native #6662 typed-prop policy. Official Vue always-mode still reports the same prop at severity 2, with complete fix/range retained; this is an explicit policy divergence, not official parity.'
  elif rule=='a11y/role-has-required-aria-props':
   assert 'type="checkbox"' in source and 'role="switch"' in region; row['review']='Original native input type checkbox supplies checked state for switch role. Existing producer exempts aria-checked only for statically witnessed native checkbox/radio. W3C ARIA in HTML expressly forbids redundant aria-checked here.'; row['reference']='https://www.w3.org/TR/html-aria/#el-input-checkbox'
  elif rule=='a11y/no-aria-hidden-on-focusable':
   assert '<button' in region and 'aria-hidden="true"' in region and 'tabindex="-1"' in region; row['review']='Original native button remains focusable with tabindex=-1; the existing producer correctly preserves severity 2 and full programmatic-focus help. W3C distinction between focusable and tabbable confirms it.'; row['reference']='https://www.w3.org/TR/html-aria/#att-aria-hidden'
  elif rule=='vue/component-definition-name-casing':
   stem=pathlib.PurePosixPath(file).stem; assert '.' in stem; row['physical_filename']=stem; row['review']='Original physical component filename contains a dot; existing strict PascalCase predicate uses the full physical stem and has no implicit Nuxt client/server/takumi/unused suffix exemption. This is filename policy, not a runtime SSR assertion.'
  elif rule=='ssr/no-browser-globals-in-ssr':
   if file in ['app/app.vue','app/components/Diff/MobileSidebarDrawer.vue']:
    row['status']='requires_source_correction'; row['review']='Original direct import.meta.client guard excludes this browser read on the server. Existing typeof-only analysis falsely warns; do not copy this packet into a newly approved expectation. Focused source owner must fix and qualify the complete original case.'; row['reference']='https://nuxt.com/docs/4.x/api/advanced/import-meta'
   elif file=='app/pages/package/[[org]]/[name].vue':
    row['status']='documented_unproven_indirect_boundary'; row['review']='Original DOM read is guarded through const hasEmptyPayload using import.meta.client and shallowRef.value. The current bounded lexical rule does not prove intervariable reactive state or whole-program Nuxt SSR execution. Retain full packet as an explicit analysis boundary; no claim that original Nuxt server execution crashes.'
   else: row['review']='Original unresolved browser identifier is evaluated as a top-level argument before external composable invocation. Existing lexical rule reports that runtime read. Physical .client filename is not a configured rule exemption; no claim of complete Nuxt SSR behavior.'
  rows.append(row)
assert len(rows)==84
(p/'npmx-new-whole-policy-review.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'wholeMessages':len(rows),'statuses':collections.Counter(r['status'] for r in rows),'sourcePin':originalpin,'previousSnapshotCommit':previous,'officialCases':len(oracle['captures'])}))
