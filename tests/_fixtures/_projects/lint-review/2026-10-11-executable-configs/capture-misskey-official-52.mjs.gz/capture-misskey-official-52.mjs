import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import { createRequire } from 'node:module';
import { createHash } from 'node:crypto';
import { recordOraclePackets } from '/Users/ubugeeei/Source/github.com/ubugeeei-prod/vize/tests/tooling/support/n8n-cli-config-oracle.mjs';
const root='/Users/ubugeeei/Source/github.com/ubugeeei-prod/vize';
const evidence='/tmp/vize-app-e2e-lint-diagnosis-20261011';
const sourceRoot='/Users/ubugeeei/Source/github.com/ubugeeei-prod/vize.fix-app-e2e-lint-fixture-dependencies-20261011/tests/_fixtures/_git/misskey/packages/frontend';
const requireProvider=createRequire(path.join(root,'tools/benchmarks/scripts/package.json'));
const {ESLint}=requireProvider('eslint');
const vue=requireProvider('eslint-plugin-vue');
const baseline=JSON.parse(fs.readFileSync(path.join(evidence,'misskey-official-all51-capture.json'),'utf8'));
const rules={...baseline.configurations[0].rules,'vue/no-required-prop-with-default':'error'};
assert.equal(Object.keys(rules).length,52);
for(const [key,value] of Object.entries(baseline.configurations[0].rules))assert.deepEqual(rules[key],value);
const eslint=new ESLint({cwd:root,overrideConfigFile:true,overrideConfig:[...vue.configs['flat/base'],{files:['**/*.vue'],languageOptions:{parser:requireProvider('vue-eslint-parser'),parserOptions:{parser:requireProvider('@typescript-eslint/parser'),ecmaVersion:'latest',sourceType:'module'}},plugins:{vue},rules}]});
const captures=[];
const rawLog=fs.openSync(path.join(evidence,'misskey-official-52-raw.jsonl'),'w');
for(const original of baseline.captures){
 const recordedFilePath=`misskey/packages/frontend/${original.caseId}.vue`;
 const source=fs.readFileSync(path.join(sourceRoot,`${original.caseId}.vue`),'utf8');
 const rawPackets=await eslint.lintText(source,{filePath:path.join(root,recordedFilePath)});
 const capture={configuration:'latest-cli-plus-required-prop-default',caseId:original.caseId,sourceSha256:createHash('sha256').update(source).digest('hex'),...recordOraclePackets(rawPackets,recordedFilePath)};
 fs.writeSync(rawLog,JSON.stringify(capture)+'\n');
 captures.push(capture);
}
fs.closeSync(rawLog);
const receipt={providers:baseline.providers,officialVueBase:baseline.officialVueBase,originalProjectionSha256:baseline.projectionSha256,rules,captures};
fs.writeFileSync(path.join(evidence,'misskey-official-52-capture.json'),JSON.stringify(receipt,null,2)+'\n');
for(const capture of captures){
 const matches=capture.packets.flatMap(p=>p.messages).filter(m=>m.ruleId==='vue/no-required-prop-with-default');
 if(matches.length)console.log(JSON.stringify({caseId:capture.caseId,messages:matches}));
}
console.log(JSON.stringify({files:captures.length,rules:52,sha256:createHash('sha256').update(fs.readFileSync(path.join(evidence,'misskey-official-52-capture.json'))).digest('hex')}));
