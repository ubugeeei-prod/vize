from pathlib import Path
import json,gzip,hashlib,subprocess,zipfile,base64
base=Path('/tmp/vize-app-e2e-lint-diagnosis-20261011'); target=Path('tests/_fixtures/_projects/lint-review/2026-10-11-direct-client-correction'); target.mkdir(exist_ok=True)
artifact=base/'8589-bb9-lint-11694658468.zip'; extracted=artifact.with_suffix(''); observed='bb9da4ac8ab014948b1da9cd591aa7e1a3786fd2'; corrected='0106fc97ed29aa499c46c485d388038acebb7510'
sha=lambda b:hashlib.sha256(b).hexdigest()
def write(name,obj):
 b=(json.dumps(obj,ensure_ascii=False,indent=2)+'\n').encode(); (target/name).write_bytes(gzip.compress(b,mtime=0) if name.endswith('.gz') else b)
assert sha(artifact.read_bytes())=='268719dbfcc174f69af07b90b8dba263156f2fe2b511c36ee89adf95b7576c99'
(target/'original-provider-artifact.zip').write_bytes(artifact.read_bytes())
log=base/'8589-bb9-lint-all-114409356937.log'; (target/'original-job.log.gz').write_bytes(gzip.compress(log.read_bytes(),mtime=0))
write('provider-run-metadata.json.gz',json.loads((base/'8589-bb9-lint-run-metadata.json').read_text()))
write('runtime-fixture-receipts.json.gz',{p.name.removesuffix('.json'):json.loads(p.read_text()) for p in sorted((extracted/'.vize/artifacts/lint-fixtures').glob('*.json'))})
captures=[]; changes=[]; sources=[]
for project in ['misskey','npmx.dev','vuefes-2025']:
 path=f'tests/snapshots/lint/__snapshots__/{project}-lint.snap'; a=extracted/(path+'.actual'); b=(base/'8589-corrected-lint-11692924427'/(path+'.actual')) if project!='vuefes-2025' else Path(path)
 raw=a.read_text(); baseline=b.read_bytes() if project!='vuefes-2025' else next(c['raw'].encode() for c in json.loads(gzip.decompress(Path('tests/_fixtures/_projects/lint-review/2026-10-11/original-provider-packets.json.gz').read_bytes())) if c['path']==path); actual=json.loads(raw); previous=json.loads(baseline); assert [p['file'] for p in actual]==[p['file'] for p in previous]
 captures.append({'project':project,'path':path,'raw':raw,'sha256':sha(a.read_bytes()),'baselineRaw':baseline.decode(),'baselineSha256':sha(baseline),'files':len(actual)})
 for old,new in zip(previous,actual):
  if old==new:continue
  removed=[m for m in old['messages'] if m not in new['messages']];added=[m for m in new['messages'] if m not in old['messages']]
  assert len(removed)==1 and not added and removed[0]['ruleId']=='ssr/no-browser-globals-in-ssr'
  assert {**old,'messages':new['messages'],'warningCount':old['warningCount']-1}==new
  changes.append({'project':project,'file':old['file'],'expected':old,'actual':new,'removedWholeMessage':removed[0]})
  pin='8eff3cd7dd79a7f47bbf2b78202b9aa2070ec5a6' if project=='vuefes-2025' else 'c9e8be91e61eeeae956e2068722caa09e293cc68'
  if project=='vuefes-2025':
   d=json.loads((base/'vuefes-timetable-original-api.json').read_text()); source=base64.b64decode(d['content']); blob=d['sha']
  else:
   fixture=Path('tests/_fixtures/_git')/project
   source=subprocess.check_output(['git','-C',str(fixture),'show',pin+':'+old['file']]);blob=subprocess.check_output(['git','-C',str(fixture),'rev-parse',pin+':'+old['file']],text=True).strip()
  assert hashlib.sha1(b'blob '+str(len(source)).encode()+b'\0'+source).hexdigest()==blob
  sources.append({'project':project,'file':old['file'],'sourcePin':pin,'gitBlob':blob,'gitMode':'100644','sourceSha256':sha(source),'source':source.decode(),'clientGuard':'positive direct import.meta.client','status':'reviewed_source_correction'})
write('original-provider-packets.json.gz',captures);write('whole-correction-review.json.gz',changes);write('original-source-witnesses.json.gz',sources)
helper='crates/vize_patina/src/rules/ssr/no_browser_globals_in_ssr/typeof_guard.rs'
write('producer-source-provenance.json.gz',[{'head':head,'path':helper,'gitBlob':subprocess.check_output(['git','rev-parse',head+':'+helper],text=True).strip(),'source':subprocess.check_output(['git','show',head+':'+helper],text=True)} for head in [observed,corrected]])
with zipfile.ZipFile(artifact) as z:entries=z.namelist()
write('binding.json',{'observedSourceHead':observed,'observedSSRSourceHead':'1edd0aab0bf708a84d23a3e41ccf42f818ebdf13','genericBoundaryCorrectionHead':corrected,'run':38118859501,'job':114409356937,'runConclusion':'failure','lintCasesPassed':12,'lintCasesRequired':15,'artifactId':11694658468,'artifactSha256':sha(artifact.read_bytes()),'jobRawLogSha256':sha(log.read_bytes()),'originalZipEntries':entries,'filesRequired':874,'misskeyWholePacketsUnchanged':583,'changedWholePackets':3,'removedWholeMessages':3,'indirectStateBoundaryUnproven':1,'finalCorrectedSourceFull15StillRequired':True})
write('inventory.json',[{'path':p.name,'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())} for p in sorted(target.iterdir()) if p.name!='inventory.json'])
print(json.dumps({'projects':len(captures),'files':sum(c['files'] for c in captures),'changedWholePackets':len(changes),'removedWholeMessages':len(changes),'entries':len(list(target.iterdir()))}))
