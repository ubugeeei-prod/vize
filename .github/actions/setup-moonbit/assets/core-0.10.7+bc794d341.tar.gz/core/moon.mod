name = "moonbitlang/core"

version = "0.10.7+bc794d341"

readme = "README.md"

repository = "https://github.com/moonbitlang/core"

license = "Apache-2.0"

keywords = [ "core", "standard library" ]

warnings = "+test_unqualified_package+unqualified_local_using+missing_doc+unnecessary_view_op+unnecessary_annotation+prefer_fixed_array+prefer_readonly_array-implicit_use_builtin+implicit_impl_as_method"
