# HashMap

A mutable hash map based on a Robin Hood hash table.

## How It Works

Entries live in one flat power-of-two array of `{psl, hash, key, value}`
slots, where `psl` (probe sequence length) is how far the entry sits from its
ideal slot `hash & (capacity - 1)`. Insertion keeps probe distances short by
letting a "poor" entry (large `psl`) evict a "rich" one (smaller `psl`),
which then continues looking for a home — that is the Robin Hood part.
Lookups can stop as soon as they meet a slot whose `psl` is smaller than the
distance probed so far, so misses are cheap too.

```mermaid
flowchart TD
  S["set(k, v)"] --> H["idx = hash & mask, psl = 0"]
  H --> C{"entries[idx]?"}
  C -->|"same hash and key"| U["update value in place"]
  C -->|"occupied, psl ≤ slot's psl"| N["idx = (idx + 1) & mask, psl += 1"] --> C
  C -->|"empty, or occupied with psl > slot's psl"| G{"size ≥ capacity / 2?"}
  G -->|"yes"| R["double capacity, rehash all, restart"] --> H
  G -->|"no, slot was empty"| P["store {psl, hash, k, v}"]
  G -->|"no, stealing"| E["swap: evict the richer entry,<br/>keep probing to re-place it"] --> N
```

# Usage

## Create

You can create an empty map using `HashMap([])` or construct it from entries using `HashMap([...])`.

```mbt check
///|
test {
  let _map1 = @hashmap.HashMap([("a", 1), ("b", 2)])
  let _map2 : @hashmap.HashMap[String, Int] = HashMap([])
}
```

## Set & Get

You can use `set()` to add a key-value pair to the map, and use `get()` to get a value.

```mbt check
///|
test {
  let map : @hashmap.HashMap[String, Int] = HashMap([])
  map.set("a", 1)
  @test.assert_eq(map.get("a"), Some(1))
  @test.assert_eq(map.get_or_default("a", 0), 1)
  @test.assert_eq(map.get_or_default("b", 0), 0)
  map.remove("a")
  @test.assert_eq(map.contains("a"), false)
}
```

## Remove

You can use `remove()` to remove a key-value pair.

```mbt check
///|
test {
  let map = @hashmap.from_array([("a", 1), ("b", 2), ("c", 3)])
  map.remove("a") |> ignore
  assert_false(map.contains("a"))
}
```

## Contains

You can use `contains()` to check whether a key exists.

```mbt check
///|
test {
  let map = @hashmap.from_array([("a", 1), ("b", 2), ("c", 3)])
  @test.assert_eq(map.contains("a"), true)
  @test.assert_eq(map.contains("d"), false)
}
```

## Size & Capacity

You can use `size()` to get the number of key-value pairs in the map, or `capacity()` to get the current capacity.

```mbt check
///|
test {
  let map = @hashmap.from_array([("a", 1), ("b", 2), ("c", 3)])
  @test.assert_eq(map.length(), 3)
  @test.assert_eq(map.capacity(), 8)
}
```

Similarly, you can use `is_empty()` to check whether the map is empty.

```mbt check
///|
test {
  let map : @hashmap.HashMap[String, Int] = HashMap([])
  @test.assert_eq(map.is_empty(), true)
}
```

## Clear

You can use `clear` to remove all key-value pairs from the map, but the allocated memory will not change.

```mbt check
///|
test {
  let map = @hashmap.from_array([("a", 1), ("b", 2), ("c", 3)])
  map.clear()
  @test.assert_eq(map.is_empty(), true)
}
```

## Iteration

You can use `each()` or `eachi()` to iterate through all key-value pairs.

```mbt check
///|
test {
  let map = @hashmap.from_array([("a", 1), ("b", 2), ("c", 3)])
  let arr = []
  map.each((k, v) => arr.push((k, v)))
  let arr2 = []
  map.eachi((i, k, v) => arr2.push((i, k, v)))
}
```

Or use `iter()`, `keys()`, or `values()` to get iterators:

```mbt check
///|
test {
  let map = @hashmap.from_array([("a", 1)])
  let _iter = map.iter()
  let _keys = map.keys()
  let _vals = map.values()
}
```

## Get or Initialize

Use `get_or_init()` to get a value or initialize it if missing:

```mbt check
///|
test {
  let map : @hashmap.HashMap[String, Int] = HashMap([])
  let val = map.get_or_init("key", () => 42)
  @test.assert_eq(val, 42)
  @test.assert_eq(map.get("key"), Some(42))
}
```

## Transform and Filter

Use `map()` to transform values and `retain()` to filter in place:

```mbt check
///|
test {
  let map = @hashmap.from_array([(1, "a"), (2, "b")])
  let mapped = map.map((k, _v) => k * 10)
  @test.assert_eq(mapped.get(1), Some(10))
  let map2 = @hashmap.from_array([("a", 1), ("b", 2), ("c", 3)])
  map2.retain((_k, v) => v > 1)
  @test.assert_eq(map2.contains("a"), false)
  @test.assert_eq(map2.contains("b"), true)
}
```

## Index Access

Use subscript syntax `map[key]` for direct access. Panics if the key is not found.

```mbt check
///|
test {
  let map = @hashmap.from_array([("x", 10), ("y", 20)])
  @test.assert_eq(map["x"], 10)
  map["z"] = 30
  @test.assert_eq(map["z"], 30)
}
```

## Contains Key-Value

`contains_kv()` checks whether a specific key-value pair exists (not just the key).

```mbt check
///|
test {
  let map = @hashmap.from_array([("a", 1), ("b", 2)])
  @test.assert_eq(map.contains_kv("a", 1), true)
  @test.assert_eq(map.contains_kv("a", 99), false)
}
```

## Copy

`copy()` creates a shallow clone.

```mbt check
///|
test {
  let map = @hashmap.from_array([("a", 1)])
  let cloned = map.copy()
  cloned.set("b", 2)
  @test.assert_eq(map.contains("b"), false) // original unchanged
}
```

## From Iterator

```mbt check
///|
test {
  let map = @hashmap.from_iter([("a", 1), ("b", 2)].iter())
  @test.assert_eq(map.length(), 2)
}
```

## Merging

`merge()` returns a new map combining both. `merge_in_place()` mutates the receiver. On key conflicts, the right map's value wins.

```mbt check
///|
test {
  let m1 = @hashmap.from_array([("a", 1)])
  let m2 = @hashmap.from_array([("b", 2)])
  let merged = m1.merge(m2)
  @test.assert_eq(merged.get("a"), Some(1))
  @test.assert_eq(merged.get("b"), Some(2))
  // merge_in_place
  let m3 = @hashmap.from_array([("x", 1)])
  let m4 = @hashmap.from_array([("y", 2)])
  m3.merge_in_place(m4)
  @test.assert_eq(m3.contains("y"), true)
}
```
